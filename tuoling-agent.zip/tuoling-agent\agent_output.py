"""
本程序仅用于驼灵智能体大赛学术模拟，不构成真实市场投资建议。
agent_output.py —— 赛事标准JSON格式化工具
职责：
  1. 接收选股结果，输出纯净无多余内容JSON数组
  2. 双重校验：volume为100倍数、symbol为6位数字字符串
  3. 无操作直接返回纯文本[]
"""

import json
import re
import logging
from typing import List, Dict

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)


class OutputFormatter:
    """
    大赛标准输出格式化器

    纯净JSON格式（无注释、无换行修饰、无多余空格）:
    [
      {
        "symbol": "6位数字代码字符串",
        "symbol_name": "股票简称",
        "volume": "100整数倍买入股数"
      }
    ]

    无操作直接返回: []
    """

    def __init__(self):
        pass

    @staticmethod
    def validate_symbol(symbol: str) -> bool:
        """
        校验股票代码是否符合6位数字格式

        参数:
          symbol: 股票代码字符串

        返回:
          True = 合规 6位数字 / False = 不合规
        """
        if not isinstance(symbol, str):
            return False
        # 必须是6位纯数字
        return bool(re.match(r'^\d{6}$', symbol))

    @staticmethod
    def validate_volume(volume: int) -> bool:
        """
        校验股数是否为100的正整数倍（A股手数铁律）

        参数:
          volume: 买入股数

        返回:
          True = 合规（100的正整数倍）/ False = 不合规
        """
        return isinstance(volume, int) and volume > 0 and volume % 100 == 0

    def format_entry(self, symbol: str, symbol_name: str, volume: int) -> Dict:
        """
        格式化单条交易指令

        参数:
          symbol: 6位股票代码
          symbol_name: 股票简称
          volume: 买入股数（100整数倍）

        返回:
          合规的JSON字典，校验失败抛出AssertionError
        """
        # ---- 双重校验1：symbol是6位数字 ----
        assert self.validate_symbol(symbol), \
            f"symbol校验失败: '{symbol}' 不是6位数字代码"

        # ---- 双重校验2：volume是100整数倍 ----
        assert self.validate_volume(volume), \
            f"volume校验失败: {volume} 不是100的正整数倍"

        return {
            "symbol": symbol,
            "symbol_name": str(symbol_name),
            "volume": str(volume)  # 大赛要求volume为字符串
        }

    def format_output(self, positions: List[Dict]) -> str:
        """
        将持仓列表格式化为赛事标准JSON字符串

        参数:
          positions: 持仓列表，每项包含 symbol/name/volume

        返回:
          纯净JSON字符串（无换行、无多余空格）
        """
        if not positions or len(positions) == 0:
            return "[]"

        entries = []
        for pos in positions:
            entry = self.format_entry(
                symbol=pos['symbol'],
                symbol_name=pos.get('name', pos['symbol']),
                volume=pos['volume']
            )
            entries.append(entry)

        # 输出纯净JSON（无缩进、无换行）
        output = json.dumps(entries, ensure_ascii=False, separators=(',', ':'))
        return output

    @staticmethod
    def print_pure_json(json_str: str):
        """
        打印纯净JSON到stdout（大赛平台自动读取）
        绝无多余文字
        """
        print(json_str)


def validate_and_format(positions: List[Dict]) -> str:
    """
    快捷函数：校验并格式化输出JSON
    """
    fmt = OutputFormatter()
    return fmt.format_output(positions)


# ============================================================================
# 自测
# ============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("agent_output.py 自测")
    print("=" * 60)

    fmt = OutputFormatter()

    # 测试1：正常3只股票
    print("\n[测试1] 正常3只选股输出:")
    test_positions = [
        {'symbol': '600036', 'name': '招商银行', 'volume': 500},
        {'symbol': '002594', 'name': '比亚迪', 'volume': 100},
        {'symbol': '000725', 'name': '京东方A', 'volume': 2000},
    ]
    result = fmt.format_output(test_positions)
    print(f"  输出: {result}")
    # 解析验证
    parsed = json.loads(result)
    assert len(parsed) == 3
    for item in parsed:
        assert len(item['symbol']) == 6
        assert int(item['volume']) % 100 == 0
    print("  [PASS] 校验通过")

    # 测试2：空仓
    print("\n[测试2] 空仓输出:")
    result = fmt.format_output([])
    print(f"  输出: {result}")
    assert result == "[]"
    print("  [PASS] 空仓校验通过")

    # 测试3：volume非100倍数（应该触发assert）
    print("\n[测试3] volume非100倍数（应触发AssertionError）:")
    try:
        fmt.format_output([
            {'symbol': '600036', 'name': '测试', 'volume': 150}
        ])
        print("  [FAIL] 未触发预期错误!")
    except AssertionError as e:
        print(f"  [PASS] 正确拦截: {e}")

    # 测试4：symbol非6位（应该触发assert）
    print("\n[测试4] symbol非6位（应触发AssertionError）:")
    try:
        fmt.format_output([
            {'symbol': '60003', 'name': '测试', 'volume': 100}
        ])
        print("  [FAIL] 未触发预期错误!")
    except AssertionError as e:
        print(f"  [PASS] 正确拦截: {e}")

    print("\n所有自测通过!")
