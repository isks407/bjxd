"""
本程序仅用于驼灵智能体大赛学术模拟，不构成真实市场投资建议。
web_agent.py —— 驼灵智能体大赛「智投未来」Gradio Web 交互界面
"""

import os
import sys
import json
import time
from datetime import datetime

# 清除代理（确保 Gradio 隧道正常）
for _pv in ["http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "all_proxy"]:
    os.environ.pop(_pv, None)
os.environ["NO_PROXY"] = "*"
os.environ["PYTHONUNBUFFERED"] = "1"

import gradio as gr
import pandas as pd
import numpy as np

# 导入智能体核心模块
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from capital_manager import CapitalManager
from strategy_core import FactorScorer, AttributionGenerator, StockSelectionEngine
from agent_output import OutputFormatter
from data_fetch import AStockDataFetcher
from explain_report import ReportGenerator

# ============================================================
# 主题 & CSS（投屏答辩优化 - 增强质感版）
# ============================================================

CUSTOM_THEME = gr.themes.Soft(
    primary_hue="indigo",
    secondary_hue="slate",
    neutral_hue="slate",
    font=gr.themes.GoogleFont("Noto Sans SC"),
).set(
    # 多层渐变背景 —— 深邃质感
    body_background_fill="linear-gradient(175deg, #eef2ff 0%, #f1f5f9 25%, #f8fafc 50%, #ede9fe 75%, #eef2ff 100%)",
    body_background_fill_dark="linear-gradient(175deg, #0f0d1a 0%, #1a1035 25%, #0f172a 50%, #1a1035 75%, #0f0d1a 100%)",
    # 毛玻璃卡片
    block_background_fill="rgba(255,255,255,0.72)",
    block_background_fill_dark="rgba(30,41,59,0.78)",
    block_border_width="1px",
    block_border_color="rgba(148,163,184,0.18)",
    block_border_color_dark="rgba(100,116,139,0.2)",
    block_shadow="0 8px 32px rgba(79,70,229,0.06), 0 2px 8px rgba(0,0,0,0.04), inset 0 1px 0 rgba(255,255,255,0.6)",
    block_radius="18px",
    block_title_text_color="#1e293b",
    block_title_text_color_dark="#e2e8f0",
    # 主按钮
    button_primary_background_fill="linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #6366f1 100%)",
    button_primary_background_fill_hover="linear-gradient(135deg, #4338ca 0%, #6d28d9 50%, #4f46e5 100%)",
    button_primary_text_color="#ffffff",
    button_primary_border_color="transparent",
    button_primary_shadow="0 4px 20px rgba(79,70,229,0.4), 0 1px 3px rgba(0,0,0,0.1)",
    # 次要按钮
    button_secondary_background_fill="rgba(255,255,255,0.75)",
    button_secondary_background_fill_hover="rgba(255,255,255,0.95)",
    button_secondary_border_color="rgba(148,163,184,0.3)",
    button_secondary_text_color="#4f46e5",
    # 输入框
    input_background_fill="rgba(248,250,252,0.7)",
    input_background_fill_dark="rgba(30,41,59,0.7)",
    input_border_color="rgba(148,163,184,0.25)",
    input_border_color_focus="#4f46e5",
    input_shadow="0 1px 3px rgba(0,0,0,0.04)",
    input_shadow_focus="0 0 0 4px rgba(79,70,229,0.12)",
    input_radius="12px",
    # 全局
    body_text_size="16px",
    body_text_color="#334155",
    body_text_color_dark="#cbd5e1",
    # 表格
    table_border_color="rgba(226,232,240,0.6)",
    table_even_background_fill="rgba(248,250,252,0.6)",
    # 区块间距
    block_padding="24px",
    container_radius="18px",
)

# 页面头部注入 —— 背景粒子画布 + 预加载字体
PAGE_HEAD = """
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Noto+Sans+SC:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ===== 全局质感背景 ===== */
body {
    background-attachment: fixed !important;
}
.gradio-container {
    max-width: 1200px !important;
    margin: 0 auto !important;
}

/* ===== 背景动态网格纹理层（伪元素实现） ===== */
body::before {
    content: '';
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    pointer-events: none; z-index: 0;
    background-image:
        /* 对角线网格 */
        repeating-linear-gradient(
            45deg,
            transparent,
            transparent 40px,
            rgba(79,70,229,0.015) 40px,
            rgba(79,70,229,0.015) 41px
        ),
        /* 水平细线 */
        repeating-linear-gradient(
            0deg,
            transparent,
            transparent 80px,
            rgba(148,163,184,0.02) 80px,
            rgba(148,163,184,0.02) 81px
        );
    mask-image: radial-gradient(ellipse 100% 80% at 50% 0%, black 30%, transparent 70%);
    -webkit-mask-image: radial-gradient(ellipse 100% 80% at 50% 0%, black 30%, transparent 70%);
}

/* ===== 顶部光晕装饰 ===== */
body::after {
    content: '';
    position: fixed; top: -180px; left: 50%;
    transform: translateX(-50%);
    width: 900px; height: 500px;
    pointer-events: none; z-index: 0;
    background: radial-gradient(ellipse at center,
        rgba(79,70,229,0.08) 0%,
        rgba(124,58,237,0.04) 35%,
        transparent 70%
    );
    animation: glowPulse 8s ease-in-out infinite;
}
@keyframes glowPulse {
    0%, 100% { opacity: 0.6; transform: translateX(-50%) scale(1); }
    50%      { opacity: 1.0; transform: translateX(-50%) scale(1.08); }
}

/* ===== 主标题 ===== */
.main-title {
    position: relative; z-index: 2;
    padding: 32px 0 4px;
}
.main-title h1 {
    font-size: 2.8rem !important;
    font-weight: 700 !important;
    text-align: center;
    letter-spacing: 0.04em;
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 40%, #a78bfa 70%, #6366f1 100%);
    background-size: 200% 200%;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    animation: titleShimmer 6s ease-in-out infinite;
    filter: drop-shadow(0 2px 8px rgba(79,70,229,0.15));
}
@keyframes titleShimmer {
    0%, 100% { background-position: 0% 50%; }
    50%      { background-position: 100% 50%; }
}

/* ===== 副标题 ===== */
.subtitle {
    position: relative; z-index: 2;
    text-align: center; color: #64748b;
    font-size: 1.05rem; font-weight: 400;
    margin-bottom: 20px; letter-spacing: 0.06em;
}
.subtitle::after {
    content: '';
    display: block; width: 60px; height: 3px;
    margin: 12px auto 0;
    border-radius: 2px;
    background: linear-gradient(90deg, transparent, #a78bfa, transparent);
}

/* ===== Tab 导航增强 ===== */
.tabs {
    position: relative; z-index: 2;
}
.tabs > .tab-nav {
    background: rgba(255,255,255,0.5) !important;
    backdrop-filter: blur(20px) saturate(180%);
    -webkit-backdrop-filter: blur(20px) saturate(180%);
    border: 1px solid rgba(148,163,184,0.15) !important;
    border-radius: 16px !important;
    padding: 6px !important;
    gap: 4px !important;
    box-shadow: 0 4px 16px rgba(0,0,0,0.04);
}
.tabs > .tab-nav button {
    border-radius: 12px !important;
    padding: 10px 22px !important;
    font-weight: 500 !important;
    font-size: 15px !important;
    letter-spacing: 0.03em;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
    position: relative;
    overflow: hidden;
}
.tabs > .tab-nav button.selected {
    background: linear-gradient(135deg, #4f46e5, #7c3aed) !important;
    color: #fff !important;
    box-shadow: 0 4px 16px rgba(79,70,229,0.35), 0 1px 3px rgba(0,0,0,0.1) !important;
    transform: translateY(-1px);
}
.tabs > .tab-nav button:hover:not(.selected) {
    background: rgba(79,70,229,0.06) !important;
    color: #4f46e5 !important;
}

/* ===== 卡片玻璃质感 ===== */
.gradio-container .gr-group,
.gradio-container .gr-box,
.gradio-container .gr-form,
.gradio-container .gr-panel {
    background: rgba(255,255,255,0.65) !important;
    backdrop-filter: blur(24px) saturate(180%) !important;
    -webkit-backdrop-filter: blur(24px) saturate(180%) !important;
    border: 1px solid rgba(255,255,255,0.6) !important;
    border-radius: 18px !important;
    box-shadow:
        0 8px 32px rgba(79,70,229,0.05),
        0 2px 8px rgba(0,0,0,0.03),
        inset 0 1px 0 rgba(255,255,255,0.7) !important;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
}
.gradio-container .gr-group:hover,
.gradio-container .gr-panel:hover {
    box-shadow:
        0 12px 40px rgba(79,70,229,0.1),
        0 4px 12px rgba(0,0,0,0.05),
        inset 0 1px 0 rgba(255,255,255,0.8) !important;
}

/* ===== 按钮质感增强 ===== */
.gr-button-primary {
    position: relative; overflow: hidden;
    font-weight: 600 !important; letter-spacing: 0.05em !important;
    transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1) !important;
}
.gr-button-primary::after {
    content: ''; position: absolute;
    top: -50%; left: -50%; width: 200%; height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.25) 0%, transparent 60%);
    opacity: 0; transition: opacity 0.4s;
}
.gr-button-primary:hover {
    transform: translateY(-3px) !important;
    box-shadow: 0 8px 28px rgba(79,70,229,0.45), 0 2px 6px rgba(0,0,0,0.12) !important;
}
.gr-button-primary:hover::after { opacity: 1; }
.gr-button-primary:active {
    transform: translateY(-1px) !important;
}

/* ===== 输入框质感 ===== */
.gr-textbox textarea,
.gr-textbox input {
    background: rgba(248,250,252,0.6) !important;
    backdrop-filter: blur(10px) !important;
    border: 1.5px solid rgba(148,163,184,0.2) !important;
    border-radius: 12px !important;
    font-size: 16px !important;
    line-height: 1.8 !important;
    transition: all 0.3s ease !important;
}
.gr-textbox textarea:focus,
.gr-textbox input:focus {
    border-color: #4f46e5 !important;
    box-shadow: 0 0 0 4px rgba(79,70,229,0.1), 0 2px 8px rgba(79,70,229,0.08) !important;
    background: rgba(255,255,255,0.9) !important;
}

/* ===== 结果展示区 ===== */
.result-box {
    position: relative; z-index: 2;
    background: rgba(255,255,255,0.7) !important;
    backdrop-filter: blur(20px) saturate(180%) !important;
    -webkit-backdrop-filter: blur(20px) saturate(180%) !important;
    border: 1px solid rgba(226,232,240,0.6) !important;
    border-radius: 18px !important;
    padding: 32px 36px !important;
    box-shadow:
        0 8px 32px rgba(79,70,229,0.05),
        0 2px 8px rgba(0,0,0,0.03),
        inset 0 1px 0 rgba(255,255,255,0.5) !important;
    font-size: 15px; line-height: 1.9;
}
.result-box h1 {
    font-size: 1.8rem !important; color: #1e293b !important;
    text-align: center; font-weight: 700 !important;
    border-bottom: 2px solid transparent;
    border-image: linear-gradient(90deg, transparent, #4f46e5, transparent) 1;
    padding-bottom: 16px; margin-bottom: 22px;
}
.result-box h2 {
    font-size: 1.25rem !important; color: #334155 !important;
    font-weight: 600 !important;
    border-left: 4px solid #4f46e5;
    padding: 4px 0 4px 14px; margin-top: 28px;
    background: linear-gradient(90deg, rgba(79,70,229,0.04), transparent);
    border-radius: 0 8px 8px 0;
}
.result-box table {
    width: 100%; border-collapse: collapse; margin: 16px 0;
    font-size: 14px; border-radius: 12px; overflow: hidden;
    box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}
.result-box th {
    background: linear-gradient(180deg, #f8fafc, #f1f5f9);
    color: #1e293b; padding: 12px 16px;
    text-align: left; font-weight: 600;
    border-bottom: 1.5px solid #e2e8f0;
}
.result-box td {
    padding: 11px 16px;
    border-bottom: 1px solid #f1f5f9;
    background: rgba(255,255,255,0.4);
}
.result-box tr:hover td {
    background: rgba(79,70,229,0.03);
}
.result-box hr {
    border: none; height: 1px;
    background: linear-gradient(90deg, transparent, #cbd5e1 20%, #cbd5e1 80%, transparent);
    margin: 24px 0;
}

/* ===== JSON暗色代码块 ===== */
.result-box code, .json-box {
    background: linear-gradient(160deg, #1e293b 0%, #0f172a 100%) !important;
    color: #22d3ee !important;
    border-radius: 14px !important; padding: 20px 24px !important;
    font-family: 'JetBrains Mono', 'Cascadia Code', 'Fira Code', monospace !important;
    font-size: 14px !important; line-height: 1.7;
    white-space: pre-wrap; overflow-x: auto;
    border: 1px solid rgba(100,116,139,0.2) !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.05), 0 4px 16px rgba(0,0,0,0.1) !important;
    display: block;
}

/* ===== 警告/提示框 ===== */
.warn-box {
    border: 1.5px solid rgba(245,158,11,0.3) !important;
    border-radius: 14px !important; padding: 18px !important;
    background: linear-gradient(135deg, rgba(255,251,235,0.8), rgba(254,243,199,0.6)) !important;
    backdrop-filter: blur(10px) !important;
}

/* ===== Accordion 折叠面板 ===== */
.gr-accordion {
    background: rgba(255,255,255,0.4) !important;
    backdrop-filter: blur(16px) !important;
    border-radius: 14px !important;
    border: 1px solid rgba(148,163,184,0.12) !important;
    overflow: hidden;
}

/* ===== Dropdown 下拉菜单 ===== */
.gr-dropdown {
    border-radius: 12px !important;
}

/* ===== 页脚隐藏 ===== */
footer { visibility: hidden; }

/* ===== 滚动条美化 ===== */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb {
    background: rgba(148,163,184,0.3);
    border-radius: 3px;
}
::-webkit-scrollbar-thumb:hover { background: rgba(148,163,184,0.5); }

/* ===== 全局过渡动画 ===== */
.gr-button, .gr-textbox textarea, .gr-textbox input, .gr-group, .gr-panel {
    transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1) !important;
}
</style>
"""

# 简洁CSS（注入 gradio Blocks 用，避免与 head 重复）
CUSTOM_CSS = ""

# ============================================================
# 核心功能函数
# ============================================================

LOG_DIR = os.path.join(BASE_DIR, 'backtest_logs')
STATE_FILE = os.path.join(BASE_DIR, 'data', 'account_state.json')
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)


def run_demo_pipeline():
    """运行 Demo 全流程，返回完整结果"""
    lines = []
    lines.append("# 驼灵智能体大赛「智投未来」Demo 运行报告\n")
    lines.append(f"**运行时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    lines.append("---\n")

    # --- 资金管理器 ---
    cm = CapitalManager(initial_capital=500_000)
    cm.new_trading_day('20260101')

    test_stocks = [
        {'symbol': '600036', 'name': '招商银行', 'total_score': 85.2},
        {'symbol': '002594', 'name': '比亚迪', 'total_score': 82.5},
        {'symbol': '000725', 'name': '京东方A', 'total_score': 78.1},
    ]
    pre_closes = {'600036': 30.00, '002594': 250.00, '000725': 4.00}

    lines.append("## 1. 仓位计算\n")
    lines.append("| 股票 | 昨收 | 1手成本 | 最大手数 | 实际分配 | 占用资金 | 占比 |")
    lines.append("|------|------|---------|----------|----------|----------|------|")
    for stk in test_stocks:
        sym = stk['symbol']
        pre = pre_closes[sym]
        max_lots = cm.calc_max_lots(sym, pre)
        volume = cm.calc_volume(sym, pre)
        one_lot = int(pre * 100)
        cost = volume * pre
        ratio = cost / cm.available_capital * 100
        lines.append(f"| {stk['name']} | {pre:.2f} | {one_lot:,} | {max_lots}手 | {volume}股 | {cost:,.0f} | {ratio:.1f}% |")
    lines.append("")

    positions = cm.allocate_positions(test_stocks, pre_closes)
    total_cost = cm.total_position

    lines.append(f"**总买入**: {total_cost:,}元 ({total_cost/cm.available_capital*100:.1f}%)")
    lines.append(f"**现金缓冲**: {cm.cash_buffer:,}元\n")

    # --- 策略打分 ---
    lines.append("## 2. 多因子打分选股\n")
    mock_stocks = pd.DataFrame([
        {'symbol': '600036', 'name': '招商银行', 'latest_price': 30.50, 'pre_close': 30.00,
         'pct_chg': 1.67, 'open': 30.10, 'high': 30.80, 'low': 29.90,
         'amplitude': 3.0, 'amount': 3.5e9, 'volume_ratio': 1.2,
         'pe_dynamic': 6.5, 'pb': 0.9, 'total_mv': 7.5e11, 'pct_chg_60d': 5.2},
        {'symbol': '002594', 'name': '比亚迪', 'latest_price': 248.00, 'pre_close': 250.00,
         'pct_chg': -0.80, 'open': 249.00, 'high': 252.00, 'low': 246.00,
         'amplitude': 2.4, 'amount': 2.8e9, 'volume_ratio': 0.9,
         'pe_dynamic': 28.0, 'pb': 6.5, 'total_mv': 7.2e11, 'pct_chg_60d': -3.1},
        {'symbol': '000725', 'name': '京东方A', 'latest_price': 4.08, 'pre_close': 4.00,
         'pct_chg': 2.00, 'open': 4.02, 'high': 4.10, 'low': 4.00,
         'amplitude': 2.5, 'amount': 1.5e9, 'volume_ratio': 1.5,
         'pe_dynamic': 35.0, 'pb': 1.3, 'total_mv': 1.5e11, 'pct_chg_60d': 12.0},
    ])
    mock_fund = pd.DataFrame([
        {'symbol': '600036', 'main_net_inflow': 15000000, 'main_net_inflow_pct': 4.2},
        {'symbol': '002594', 'main_net_inflow': -5000000, 'main_net_inflow_pct': -1.8},
        {'symbol': '000725', 'main_net_inflow': 8000000, 'main_net_inflow_pct': 3.5},
    ])
    mock_fin = pd.DataFrame([
        {'symbol': '600036', 'roe': 16.5, 'net_profit': 1.48e10},
        {'symbol': '002594', 'roe': 22.0, 'net_profit': 3.0e9},
        {'symbol': '000725', 'roe': 8.2, 'net_profit': 5.0e8},
    ])
    mock_news = {'600036': 2, '002594': -1, '000725': 3}

    engine = StockSelectionEngine()
    picks = engine.select_stocks(mock_stocks, mock_fund, mock_fin, mock_news, min_score=60.0)

    lines.append("| 排名 | 代码 | 简称 | 资金 | 技术 | 基本面 | 舆情 | **总分** |")
    lines.append("|------|------|------|------|------|--------|------|----------|")
    for s in picks:
        lines.append(f"| {s.get('rank','?')} | {s['symbol']} | {s['name']} | "
                     f"{s['fund_flow_score']:.1f} | {s['technical_score']:.1f} | "
                     f"{s['fundamental_score']:.1f} | {s['sentiment_score']:.1f} | "
                     f"**{s['total_score']:.1f}** |")
    lines.append("")

    # --- 归因 ---
    lines.append("## 3. 选股归因\n")
    attr_gen = AttributionGenerator()
    for i, pick in enumerate(picks, 1):
        pos = next((p for p in positions if p['symbol'] == pick['symbol']), None)
        if pos:
            attr_text = attr_gen.generate_stock_attribution(
                pick, pos, cm.available_capital, len(picks), i
            )
            lines.append(f"```\n{attr_text}\n```\n")

    # --- 结算 ---
    lines.append("## 4. 收盘结算\n")
    close_prices = {'600036': 30.50, '002594': 248.00, '000725': 4.08}
    report = cm.settle_close(close_prices, pre_closes)
    lines.append("| 代码 | 简称 | 昨收->今收 | 盈亏 | 收益率 |")
    lines.append("|------|------|------------|------|--------|")
    for d in report['details']:
        lines.append(f"| {d['symbol']} | {d['name']} | {d['pre_close']:.2f}->{d['close']:.2f} | "
                     f"{d['pnl']:+,.2f} | {d['pnl_pct']:+.2f}% |")
    lines.append(f"\n**当日总盈亏: {report['total_pnl']:+,.2f}元**")
    lines.append(f"**次日可用: {cm.available_capital:,}元**\n")

    # --- JSON ---
    lines.append("## 5. 大赛JSON输出\n")
    fmt = OutputFormatter()
    json_out = fmt.format_output(positions[:1])
    lines.append(f"```json\n{json_out}\n```\n")

    # --- 风控 ---
    lines.append("## 6. 风控合规检查\n")
    checks = [
        ("手数铁律 (100倍数)", "OK"),
        ("单票上限15%", "OK"),
        ("总仓位10%-90%", "OK"),
        ("分散3-8只", "OK"),
        ("流动性过滤", "OK"),
        ("涨跌停过滤", "OK"),
        ("高低价股差异", "OK"),
        ("空仓兜底", "OK"),
    ]
    for check, status in checks:
        lines.append(f"- [{status}] {check}")

    lines.append("\n---\n*报告由驼灵智能体自动生成*")
    return '\n'.join(lines)


def load_account_state() -> int:
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r', encoding='utf-8') as f:
                state = json.load(f)
            return int(state.get('available_capital', 500000))
        except Exception:
            pass
    return 500000


def run_live_pipeline(progress=gr.Progress()):
    """运行真实数据全流程"""
    lines = []
    try:
        progress(0.1, desc="Step 1/5: 拉取全市场数据...")
        fetcher = AStockDataFetcher()
        stocks, funds, fins, news = fetcher.run_full_pipeline(fast_liquidity=True)

        if stocks is None or len(stocks) == 0:
            return "## 数据拉取失败\n\n无法获取A股数据，请检查网络或稍后重试。"

        progress(0.3, desc=f"Step 2/5: 多因子打分 ({len(stocks)}只)...")
        engine = StockSelectionEngine()
        picks = engine.select_stocks(stocks, funds, fins, news, min_score=60, max_picks=8)

        if len(picks) == 0:
            return "# 今日无达标标的\n\n全市场个股综合得分均低于60分阈值，根据策略规则**空仓观望**。\n\n```json\n[]\n```"

        progress(0.5, desc="Step 3/5: 仓位分配...")
        capital = load_account_state()
        cm = CapitalManager(initial_capital=capital)
        cm.new_trading_day(datetime.now().strftime('%Y%m%d'))
        pre_closes = {s['symbol']: s['pre_close'] for s in picks}
        positions = cm.allocate_positions(picks, pre_closes)

        lines.append(f"# 驼灵智能体大赛 实时运行报告\n")
        lines.append(f"**运行时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**可用资金**: {capital:,}元 | **合规标的**: {len(stocks)}只 | **选股**: {len(picks)}只\n")
        lines.append("---\n")

        lines.append("## 选股排名 (Top 10)\n")
        lines.append("| 排名 | 代码 | 简称 | 资金 | 技术 | 基本面 | 舆情 | **总分** |")
        lines.append("|------|------|------|------|------|--------|------|----------|")
        for s in picks[:10]:
            lines.append(f"| {s.get('rank','?')} | {s['symbol']} | {s['name']} | "
                         f"{s['fund_flow_score']:.1f} | {s['technical_score']:.1f} | "
                         f"{s['fundamental_score']:.1f} | {s['sentiment_score']:.1f} | "
                         f"**{s['total_score']:.1f}** |")
        lines.append("")

        progress(0.7, desc="Step 4/5: 生成归因...")
        lines.append("## 仓位分配明细\n")
        lines.append("| # | 简称 | 昨收 | 手数 | 股数 | 占用 | 占比 |")
        lines.append("|---|------|------|------|------|------|------|")
        for p in positions:
            lines.append(f"| {p['rank']} | {p['name']} | {p['pre_close']:.2f} | "
                         f"{p['lots']}手 | {p['volume']}股 | {p['cost']:,} | {p['cost_ratio']:.1f}% |")
        total_cost = sum(p['cost'] for p in positions)
        lines.append(f"\n**总买入**: {total_cost:,}元 ({total_cost/capital*100:.1f}%)")
        lines.append(f"**现金缓冲**: {capital - total_cost:,}元\n")

        progress(0.9, desc="Step 5/5: 生成JSON...")
        fmt = OutputFormatter()
        json_out = fmt.format_output(positions)
        lines.append("## 大赛JSON输出\n")
        lines.append(f"```json\n{json_out}\n```\n")

        # 归因
        lines.append("## 选股归因\n")
        attr_gen = AttributionGenerator()
        for i, pick in enumerate(picks[:len(positions)], 1):
            pos = next((p for p in positions if p['symbol'] == pick['symbol']), None)
            if pos:
                attr_text = attr_gen.generate_stock_attribution(
                    pick, pos, capital, len(positions), i
                )
                lines.append(f"```\n{attr_text}\n```\n")

        progress(1.0, desc="完成!")
        return '\n'.join(lines)

    except Exception as e:
        import traceback
        return f"## 运行异常\n\n```\n{traceback.format_exc()}\n```"


def view_reports():
    """查看历史报告列表"""
    if not os.path.exists(LOG_DIR):
        return "暂无报告，请先运行智能体。"

    files = sorted([f for f in os.listdir(LOG_DIR) if f.endswith('.md')], reverse=True)
    if not files:
        return "暂无报告。"

    lines = ["# 历史报告列表\n"]
    for f in files[:20]:
        fpath = os.path.join(LOG_DIR, f)
        size = os.path.getsize(fpath)
        mtime = datetime.fromtimestamp(os.path.getmtime(fpath)).strftime('%Y-%m-%d %H:%M')
        lines.append(f"- **{f}** ({size:,} bytes) — {mtime}")
    return '\n'.join(lines)


def load_report_content(filename: str):
    """加载指定报告内容"""
    if not filename:
        return "请从列表中选择一个报告。"
    fpath = os.path.join(LOG_DIR, filename)
    if not os.path.exists(fpath):
        return f"报告 {filename} 不存在。"
    with open(fpath, 'r', encoding='utf-8') as f:
        return f.read()


def get_report_choices():
    if not os.path.exists(LOG_DIR):
        return []
    return sorted([f for f in os.listdir(LOG_DIR) if f.endswith('.md')], reverse=True)


# ============================================================
# Gradio UI 构建
# ============================================================

def create_ui():
    with gr.Blocks(
        theme=CUSTOM_THEME,
        css=CUSTOM_CSS,
        title="驼灵智能体大赛「智投未来」",
        head=PAGE_HEAD,
        fill_height=False,
    ) as demo:

        # --- 标题 ---
        gr.HTML("""
        <div class="main-title"><h1>驼灵智能体大赛「智投未来」</h1></div>
        <div class="subtitle">日内A股交易智能体 | 多因子选股 | 归因透明 | 风控合规</div>
        """)

        with gr.Tabs():
            # ============================================================
            # Tab 1: Demo 演示
            # ============================================================
            with gr.TabItem("Demo 演示", id="tab_demo"):
                gr.Markdown("""
                > 点击下方按钮运行内置 Demo，演示完整的选股打分→仓位分配→归因生成→收盘结算全流程。
                > 使用模拟数据（招商银行30元/比亚迪250元/京东方A4元）无需联网。
                """)
                with gr.Row():
                    btn_demo = gr.Button("运行 Demo", variant="primary", size="lg", scale=0)
                output_demo = gr.Markdown(
                    "点击「运行 Demo」查看完整演示结果...",
                    elem_classes=["result-box"]
                )
                btn_demo.click(
                    fn=run_demo_pipeline,
                    outputs=[output_demo]
                )

            # ============================================================
            # Tab 2: 实时运行
            # ============================================================
            with gr.TabItem("实时运行", id="tab_live"):
                gr.Markdown("""
                > **警告**: 此功能将调用 AKShare 拉取真实A股行情数据，需要联网且耗时较长（2-5分钟）。
                > 建议在交易时段（9:30-15:00）使用以获得有效实时数据。
                """)
                with gr.Row():
                    btn_live = gr.Button("开始实时分析", variant="primary", size="lg", scale=0)
                    btn_stop = gr.Button("停止", variant="stop", size="lg", scale=0)
                output_live = gr.Markdown(
                    "点击「开始实时分析」拉取真实A股数据...",
                    elem_classes=["result-box"]
                )
                btn_live.click(
                    fn=run_live_pipeline,
                    outputs=[output_live]
                )

            # ============================================================
            # Tab 3: 报告浏览
            # ============================================================
            with gr.TabItem("报告浏览", id="tab_reports"):
                gr.Markdown("浏览和查看历史运行生成的报告文件。")
                with gr.Row():
                    btn_refresh = gr.Button("刷新列表", variant="secondary", size="sm")

                report_choices = gr.Dropdown(
                    choices=get_report_choices(),
                    label="选择报告文件",
                    interactive=True,
                )
                report_content = gr.Markdown(
                    "请选择报告查看...",
                    elem_classes=["result-box"]
                )

                btn_refresh.click(
                    fn=lambda: gr.Dropdown(choices=get_report_choices()),
                    outputs=[report_choices]
                )
                report_choices.change(
                    fn=load_report_content,
                    inputs=[report_choices],
                    outputs=[report_content]
                )

            # ============================================================
            # Tab 4: 策略参数
            # ============================================================
            with gr.TabItem("策略参数", id="tab_params"):
                gr.Markdown("""
                ## 多因子选股策略参数

                以下是当前策略的核心可调参数，修改后可在 `4.py` 或 `strategy_core.py` 中调整。
                """)
                gr.Markdown("""
                ### 四大因子权重

                | 因子 | 权重 | 核心逻辑 |
                |------|------|----------|
                | 资金流向因子 | **40%** | 主力净流入额、大单买入占比 |
                | 技术行情因子 | **25%** | 均线多头、开盘高开、振幅适中 |
                | 基本面估值因子 | **20%** | PE估值、ROE、净利润 |
                | 舆情公告因子 | **15%** | 利好公告、正面新闻舆情 |

                ### 风险控制参数

                | 参数 | 默认值 | 说明 |
                |------|--------|------|
                | 初始本金 | 500,000 元 | 大赛固定 |
                | 单票上限 | 15% | 单只股票资金占用上限 |
                | 总仓位上限 | 90% | 预留10%现金缓冲 |
                | 选股数量 | 3-8 只 | 分散持仓 |
                | 选股阈值 | 60 分 | 综合得分下限 |
                | 流动性要求 | 成交额>5000万 | 保证可成交 |
                | 手数铁律 | 100股倍数 | A股交易规则 |
                """)

            # ============================================================
            # Tab 5: 大赛规则
            # ============================================================
            with gr.TabItem("大赛规则", id="tab_rules"):
                gr.Markdown("""
                ## 驼灵智能体大赛「智投未来」核心规则

                ### 一、不可修改硬性规则

                1. **初始资金**: 固定 500,000 元虚拟本金
                2. **日内交易**: 早盘输出买入JSON，收盘强制平仓，禁止隔夜持仓
                3. **结算公式**:
                   - 买入成本 `amount = volume × 前一交易日收盘价`
                   - 单笔盈亏 `= amount × (当日收盘价 - 昨日收盘价) / 昨日收盘价`
                4. **输出格式**: 仅纯JSON数组，无多余内容
                   ```json
                   [{"symbol":"600036","symbol_name":"招商银行","volume":"2500"}]
                   ```
                5. **数据源**: AKShare

                ### 二、A股交易常识约束

                - **手数铁律**: 1手=100股，volume 必须是100的正整数倍
                - **单票上限**: 15% 当日可用资金
                - **总仓位**: ≤ 90%，预留10%现金缓冲
                - **分散持仓**: 3~8只
                - **流动性**: 近20日日均成交额 > 2亿
                - **涨跌幅**: 主板±10%、创业板/科创板±20%、ST±5%

                ### 三、评审打分项

                - 策略可解释性
                - 选股逻辑可复现
                - 仓位股数计算透明
                - 风险约束清晰
                """)

        # --- 底部 ---
        gr.HTML("""
        <div style="text-align:center;color:#94a3b8;padding:20px;font-size:13px;">
        驼灵智能体大赛「智投未来」| 本程序仅用于学术模拟，不构成真实市场投资建议
        </div>
        """)

    return demo


# ============================================================
# 启动
# ============================================================

if __name__ == '__main__':
    demo = create_ui()
    demo.queue(default_concurrency_limit=3, max_size=10)
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        inbrowser=True,
        show_error=True,
    )
