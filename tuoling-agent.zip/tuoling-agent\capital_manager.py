"""
本程序仅用于驼灵智能体大赛学术模拟，不构成真实市场投资建议。
capital_manager.py —— 资金账户核心管理类
职责：
  - 初始化50万虚拟本金，记录每日可用总资产
  - 精准计算每只股票合规最大手数 & volume（100股倍数铁律）
  - 套用 15% 单票上限 / 90% 总仓位 / 3~8只分散 规则
  - 超额自动同比例缩减
  - 执行每日收盘盈亏结算（按大赛公式），更新次日本金
  - 输出格式化资金报表
"""

import logging
import math
from typing import Dict, List, Tuple, Optional
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)


class CapitalManager:
    """
    资金仓位管理器

    【A股交易常识约束】（全部以整数运算，规避浮点精度）：
      1. 1手 = 100股，volume 必须是 100 的正整数倍
      2. 单只个股资金占用上限 ≤ 当日可用资金 × 15%
      3. 全部股票总买入资金上限 ≤ 当日可用资金 × 90%（预留10%现金缓冲）
      4. 单日买入3~8只，杜绝重仓单票
      5. 高价股（≥200元）：单手成本高 → 自动减少手数
         低价股（3-10元）：单手成本低 → 可分配更多手数
    """

    # ----------------------------------------------------------------
    # 核心常量（可调参）
    # ----------------------------------------------------------------
    INITIAL_CAPITAL: int = 500_000          # 初始虚拟本金 500,000 元（大赛固定）
    MAX_SINGLE_STOCK_RATIO: float = 0.15    # 单票资金上限 15%
    MAX_TOTAL_POSITION_RATIO: float = 0.90  # 总仓位上限 90%
    MIN_STOCKS: int = 3                     # 单日最少买入只数（不足也可少选）
    MAX_STOCKS: int = 8                     # 单日最多买入只数
    SHARES_PER_LOT: int = 100               # A股1手=100股（铁律，不可修改）

    # 高价/低价股分界线
    HIGH_PRICE_THRESHOLD: float = 200.0   # ≥200元定为高价股
    LOW_PRICE_THRESHOLD: float = 10.0     # ≤10元定为低价股

    def __init__(self, initial_capital: int = 500_000):
        """初始化资金账户"""
        self.initial_capital: int = initial_capital
        self.available_capital: int = initial_capital  # 当日可用总资产（单位：元，整数）
        self.total_position: int = 0                    # 当日总持仓金额（整数）
        self.positions: Dict[str, Dict] = {}            # 持仓明细 {symbol: {...}}
        self.trade_date: str = ''                       # 交易日日期
        self.cash_buffer: int = 0                       # 现金缓冲（10%预留）

        # 记录历史
        self.daily_records: List[Dict] = []             # 每日资金流水

        logger.info(f"资金管理器初始化完成：初始本金 {self.initial_capital:,} 元")

    # ----------------------------------------------------------------
    # 单票最大手数计算（核心公式）
    # ----------------------------------------------------------------

    def calc_max_lots(self, symbol: str, pre_close_price: float) -> int:
        """
        计算单只股票合规最大可买手数

        【大赛公式推导】:
          单票最大手数 = floor( (可用资金 × 0.15) ÷ (昨收价 × 100) )
          即: 15%资金 ÷ 1手成本，向下取整

        参数:
          symbol: 股票代码
          pre_close_price: 前一交易日收盘价（大赛买入计价基准）

        返回:
          最大手数（整数），<1 表示无法买入（资金不足买1手）
        """
        if pre_close_price <= 0:
            logger.warning(f"    {symbol} 昨收价异常({pre_close_price})，无法计算手数")
            return 0

        single_stock_cap = int(self.available_capital * self.MAX_SINGLE_STOCK_RATIO)  # 单票15%上限金额
        one_lot_cost = int(pre_close_price * self.SHARES_PER_LOT)                     # 1手成本

        if one_lot_cost <= 0:
            return 0

        max_lots = single_stock_cap // one_lot_cost  # 整数除法，自动向下取整

        # 高价股额外限制：如果1手成本超过15%上限的50%，最多买1手
        if pre_close_price >= self.HIGH_PRICE_THRESHOLD:
            if one_lot_cost > single_stock_cap * 0.5:
                max_lots = min(max_lots, 2)  # 高价股最多2手

        # 低价股宽松：3-10元区间，如果手数过少可适当放宽
        if pre_close_price <= self.LOW_PRICE_THRESHOLD and pre_close_price >= 3.0:
            max_lots = min(max_lots, int(single_stock_cap // one_lot_cost))

        return max_lots

    def calc_volume(self, symbol: str, pre_close_price: float, desired_lots: int = -1) -> int:
        """
        计算最终买入股数（volume），严格100股倍数

        流程:
          1. 先计算理论最大手数
          2. 与期望手数取小值
          3. volume = 手数 × 100
          4. 手数<1 → 返回0（放弃该标的）

        返回:
          volume（100的整数倍），或0表示放弃
        """
        max_lots = self.calc_max_lots(symbol, pre_close_price)

        if max_lots < 1:
            logger.info(f"    {symbol} 昨收{pre_close_price:.2f}，1手成本{int(pre_close_price*100)}元 > 15%上限，放弃")
            return 0

        if desired_lots > 0:
            lots = min(desired_lots, max_lots)
        else:
            lots = max_lots

        volume = lots * self.SHARES_PER_LOT

        # 【铁律断言】volume必须是100的正整数倍
        assert volume % 100 == 0, f"FATAL: {symbol} volume={volume} 不是100的倍数！"

        return volume

    # ----------------------------------------------------------------
    # 仓位分配引擎
    # ----------------------------------------------------------------

    def allocate_positions(
        self,
        stock_scores: List[Dict],
        pre_close_prices: Dict[str, float],
        min_stocks: int = 3,
        max_stocks: int = 8
    ) -> List[Dict]:
        """
        全文仓位分配主引擎

        输入:
          stock_scores: 选股打分结果列表，按总分降序
            [{'symbol': '600036', 'name': '招商银行', 'total_score': 85.2, ...}, ...]
          pre_close_prices: {symbol: 昨收价}
          min_stocks / max_stocks: 持仓数量约束

        输出:
          positions: [{'symbol': ..., 'name': ..., 'volume': ..., 'lots': ..., 'cost': ..., 'ratio': ...}, ...]

        流程:
          1. 取 top N 只高分标的（N在min_stocks~max_stocks之间）
          2. 等权分配初始手数预算
          3. 逐只计算合规volume
          4. 总额超90%→等比例缩减
          5. 返回最终分配结果
        """
        if not stock_scores or len(stock_scores) == 0:
            logger.info("    无可用标的，空仓")
            return []

        # --- 截取 top N ---
        top_n = min(len(stock_scores), max_stocks)
        # 如果高分标的不足min_stocks，有几只买几只
        actual_n = min(top_n, max_stocks)
        if len(stock_scores) >= min_stocks:
            actual_n = max(actual_n, min_stocks)
        actual_n = min(actual_n, len(stock_scores))

        candidates = stock_scores[:actual_n]
        logger.info(f"    选中 {actual_n} 只候选标的进行仓位分配")

        # --- 等权分配初始资金预算 ---
        per_stock_budget = int(self.available_capital * self.MAX_SINGLE_STOCK_RATIO)
        total_budget = int(self.available_capital * self.MAX_TOTAL_POSITION_RATIO)

        allocated = []
        total_allocated_cost = 0

        for rank, stock in enumerate(candidates, 1):
            sym = stock['symbol']
            name = stock.get('name', sym)
            pre_close = pre_close_prices.get(sym, 0)

            if pre_close <= 0:
                # 尝试从stock本身获取
                pre_close = stock.get('pre_close', 0)
            if pre_close <= 0:
                logger.warning(f"    {sym} {name} 无有效昨收价，跳过")
                continue

            # 计算最大可买手数与实际volume
            max_lots = self.calc_max_lots(sym, pre_close)
            if max_lots < 1:
                logger.info(f"    {rank}. {name}({sym}) | 昨收{pre_close:.2f} | 1手成本{int(pre_close*100)}元 → 超过15%上限，放弃")
                continue

            # 等权分配：per_stock_budget / 1手成本，取整
            one_lot_cost = int(pre_close * self.SHARES_PER_LOT)
            equal_weight_lots = per_stock_budget // one_lot_cost
            actual_lots = min(equal_weight_lots, max_lots)
            actual_lots = max(1, actual_lots)  # 至少1手

            volume = actual_lots * self.SHARES_PER_LOT
            cost = actual_lots * one_lot_cost  # 整数运算：volume × 昨收

            # 检查总额是否超限
            if total_allocated_cost + cost > total_budget:
                # 尝试缩减手数
                remaining_budget = total_budget - total_allocated_cost
                reduced_lots = remaining_budget // one_lot_cost
                if reduced_lots < 1:
                    logger.info(f"    {rank}. {name}({sym}) | 总额接近上限，跳过")
                    continue
                actual_lots = reduced_lots
                volume = actual_lots * self.SHARES_PER_LOT
                cost = actual_lots * one_lot_cost

            # 【铁律断言】volume必须是100的倍数
            assert volume % 100 == 0, f"FATAL: {sym} volume={volume} 不是100的倍数!"

            position = {
                'symbol': sym,
                'name': name,
                'lots': actual_lots,
                'volume': volume,
                'pre_close': pre_close,
                'one_lot_cost': one_lot_cost,
                'cost': cost,
                'cost_ratio': round(cost / self.available_capital * 100, 2),
                'rank': rank,
                'max_lots': max_lots,
                'score': stock['total_score'],
            }
            allocated.append(position)
            total_allocated_cost += cost

            # 日志：关键计算步骤
            logger.info(
                f"    {rank}. {name}({sym}) | 昨收{pre_close:.2f} | "
                f"1手成本{one_lot_cost:,}元 | 最大{max_lots}手 | "
                f"实际{actual_lots}手({volume}股) | 占用{cost:,}元({position['cost_ratio']:.1f}%) | "
                f"得分{stock['total_score']:.1f}"
            )

            # 达到持仓上限则停止
            if len(allocated) >= max_stocks:
                break

        # --- 总量校验 ---
        if total_allocated_cost > total_budget:
            logger.warning(
                f"    总买入{total_allocated_cost:,}元 > 上限{total_budget:,}元，等比例缩减..."
            )
            scale = total_budget / total_allocated_cost
            for pos in allocated:
                old_volume = pos['volume']
                old_lots = pos['lots']
                new_lots = max(1, int(old_lots * scale))
                pos['lots'] = new_lots
                pos['volume'] = new_lots * self.SHARES_PER_LOT
                pos['cost'] = pos['volume'] * pos['pre_close']
                # 确保 volume 是100倍数
                if pos['volume'] % 100 != 0:
                    pos['volume'] = (pos['volume'] // 100) * 100
                    pos['lots'] = pos['volume'] // 100
                    pos['cost'] = pos['volume'] * pos['pre_close']
            total_allocated_cost = sum(p['cost'] for p in allocated)
            logger.info(f"    缩减后总买入{total_allocated_cost:,}元")

        # 更新内部状态
        self.positions = {p['symbol']: p for p in allocated}
        self.total_position = total_allocated_cost
        self.cash_buffer = self.available_capital - total_allocated_cost

        # --- 最终汇总日志 ---
        logger.info(f"    === 仓位分配完成：{len(allocated)}只 | 总买入{total_allocated_cost:,}元 | "
                     f"占总资产{total_allocated_cost/self.available_capital*100:.1f}% | "
                     f"现金缓冲{self.cash_buffer:,}元 ===")

        return allocated

    # ----------------------------------------------------------------
    # 收盘结算（大赛公式）
    # ----------------------------------------------------------------

    def settle_close(
        self,
        close_prices: Dict[str, float],
        pre_close_prices: Dict[str, float]
    ) -> Dict:
        """
        日终结算

        【大赛结算公式】:
          单笔盈亏 = amount × (当日收盘价 - 昨日收盘价) / 昨日收盘价
          amount = volume × 昨日收盘价（买入成本基准）

        参数:
          close_prices: {symbol: 当日收盘价}
          pre_close_prices: {symbol: 昨日收盘价}

        返回:
          结算报告 dict
        """
        total_pnl = 0
        details = []

        for sym, pos in self.positions.items():
            close_p = close_prices.get(sym, pos['pre_close'])
            pre_p = pos['pre_close']

            # 大赛公式计算单笔盈亏
            amount = pos['volume'] * pre_p   # 买入成本基准
            if pre_p != 0:
                pnl = amount * (close_p - pre_p) / pre_p
            else:
                pnl = 0

            pnl = round(pnl, 2)
            total_pnl += pnl

            detail = {
                'symbol': sym,
                'name': pos['name'],
                'volume': pos['volume'],
                'pre_close': pre_p,
                'close': close_p,
                'amount': amount,
                'pnl': pnl,
                'pnl_pct': round((close_p - pre_p) / pre_p * 100, 2) if pre_p != 0 else 0,
            }
            details.append(detail)
            logger.info(f"    结算 {pos['name']}({sym}): 昨收{pre_p:.2f}→今收{close_p:.2f} | "
                         f"盈亏{pnl:+,.2f}元 ({detail['pnl_pct']:+.2f}%)")

        # 更新次日可用资金（按大赛规则：当日收盘结算后的全部资金）
        self.available_capital = self.available_capital + int(total_pnl)
        # 确保不为负
        self.available_capital = max(0, self.available_capital)

        # 记录当日流水
        day_record = {
            'date': self.trade_date,
            'start_capital': self.available_capital - int(total_pnl),  # 回溯
            'total_pnl': round(total_pnl, 2),
            'end_capital': self.available_capital,
            'n_positions': len(self.positions),
            'total_position_cost': self.total_position,
            'details': details,
        }
        self.daily_records.append(day_record)

        # 清仓（大赛强制当日平仓）
        self.positions = {}
        self.total_position = 0
        self.cash_buffer = 0

        logger.info(f"    === 收盘结算完成 | 当日盈亏 {total_pnl:+,.2f}元 | "
                     f"次日可用 {self.available_capital:,}元 ===")

        return day_record

    # ----------------------------------------------------------------
    # 资金报表
    # ----------------------------------------------------------------

    def generate_capital_report(self) -> str:
        """生成格式化资金账户报表"""
        lines = []
        lines.append("=" * 60)
        lines.append("【驼灵智能体大赛 - 资金账户报表】")
        lines.append(f"初始本金: {self.initial_capital:,} 元")
        lines.append(f"当前可用: {self.available_capital:,} 元")
        lines.append(f"累计盈亏: {self.available_capital - self.initial_capital:+,} 元")
        lines.append(f"累计收益率: {(self.available_capital/self.initial_capital - 1)*100:+.2f}%")
        lines.append(f"累计交易天数: {len(self.daily_records)} 天")
        lines.append("-" * 60)
        for rec in self.daily_records[-30:]:  # 最近30天
            lines.append(
                f"  {rec['date']} | 盈亏{rec['total_pnl']:+,.2f} | "
                f"持仓{rec['n_positions']}只 | 资产{rec['end_capital']:,}"
            )
        lines.append("=" * 60)
        return '\n'.join(lines)

    # ----------------------------------------------------------------
    # 交易日控制
    # ----------------------------------------------------------------

    def new_trading_day(self, date_str: str = ''):
        """初始化新交易日"""
        self.trade_date = date_str or datetime.now().strftime('%Y%m%d')
        self.total_position = 0
        self.positions = {}
        self.cash_buffer = 0
        logger.info(f">>> 新交易日 {self.trade_date} | 可用资金: {self.available_capital:,} 元")


# ============================================================================
# 自测 Demo
# ============================================================================

def demo_test():
    """
    内置测试Demo —— 模拟首日50万资金，3只测试股票自动演算
    招商银行(600036) 30元、比亚迪(002594) 250元、京东方A(000725) 4元
    """
    print("\n" + "=" * 60)
    print("资本管理器 Demo 测试 —— 首日50万资金")
    print("=" * 60)

    cm = CapitalManager(initial_capital=500_000)
    cm.new_trading_day('20260101')

    # 模拟候选标的（含分数）
    test_stocks = [
        {'symbol': '600036', 'name': '招商银行', 'total_score': 85.2},
        {'symbol': '002594', 'name': '比亚迪', 'total_score': 82.5},
        {'symbol': '000725', 'name': '京东方A', 'total_score': 78.1},
    ]
    pre_closes = {
        '600036': 30.00,   # 招商银行 30元 (低价)
        '002594': 250.00,  # 比亚迪 250元 (高价)
        '000725': 4.00,    # 京东方A 4元 (低价)
    }

    print("\n--- 逐只演算 ---")
    for stk in test_stocks:
        sym = stk['symbol']
        name = stk['name']
        pre = pre_closes[sym]
        one_lot = int(pre * 100)
        max_lots = cm.calc_max_lots(sym, pre)
        volume = cm.calc_volume(sym, pre)
        max_cost = int(cm.available_capital * 0.15)

        print(f"\n{name}({sym}):")
        print(f"  昨收价: {pre:.2f}元")
        print(f"  1手成本: {one_lot:,}元")
        print(f"  单票15%上限: {max_cost:,}元")
        print(f"  理论最大手数: {max_lots}手 → {max_lots*100}股")
        print(f"  实际分配volume: {volume}股 → 占用{volume*pre:,.0f}元")
        print(f"  volume是100倍数: {'PASS' if volume % 100 == 0 else 'FAIL'}")

    print("\n--- 批量仓位分配 ---")
    positions = cm.allocate_positions(test_stocks, pre_closes)
    print(f"\n最终持仓 {len(positions)} 只:")
    for p in positions:
        print(f"  {p['name']}({p['symbol']}) | {p['lots']}手 {p['volume']}股 | "
              f"成本{p['cost']:,}元 | 占比{p['cost_ratio']:.1f}%")

    print(f"\n总买入: {cm.total_position:,}元 ({cm.total_position/cm.available_capital*100:.1f}%)")
    print(f"现金缓冲: {cm.cash_buffer:,}元")

    # 模拟收盘结算
    print("\n--- 模拟收盘结算 ---")
    close_prices = {
        '600036': 30.50,   # +1.67%
        '002594': 248.00,  # -0.80%
        '000725': 4.08,    # +2.00%
    }
    report = cm.settle_close(close_prices, pre_closes)
    print(f"\n当日盈亏: {report['total_pnl']:+,.2f}元")
    print(f"次日可用: {cm.available_capital:,}元")

    print("\n" + cm.generate_capital_report())


if __name__ == '__main__':
    demo_test()
