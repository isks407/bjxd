"""
本程序仅用于驼灵智能体大赛学术模拟，不构成真实市场投资建议。
strategy_core.py —— 多因子打分选股引擎 + 归因文本生成器
职责：
  1. 对全市场合规标的计算四大因子分数 → 综合总分 → 排名
  2. 筛选高分达标标的，排序后对接资金管理器分配股数
  3. 自动为每一只入选股票生成完整「选股+股数分配」归因解释文本
  4. 不选股/少选股的兜底逻辑
"""

import logging
import math
from typing import Dict, List, Tuple, Optional
from datetime import datetime

import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)


# ============================================================================
# 四大选股打分因子（权重可调参）
# ============================================================================

class FactorScorer:
    """
    多因子打分器
    四大因子 + 各自权重：

    1. 资金流向因子（权重40%）—— 日内短线核心
       判断依据：主力净流入额、大单买入占比、资金持续流入态势

    2. 技术行情因子（权重25%）
       判断依据：均线多头排列、股价站稳均线、开盘小幅高开无跳水、震荡上行

    3. 基本面估值因子（权重20%）
       判断依据：PE估值合理、ROE为正、净利润正向增长

    4. 舆情公告因子（权重15%）
       判断依据：正面利好公告、财经新闻正面舆情 > 负面
    """

    # ---------- 因子权重（总和=100%）----------
    WEIGHT_FUND_FLOW: float = 0.40      # 资金流向
    WEIGHT_TECHNICAL: float = 0.25      # 技术行情
    WEIGHT_FUNDAMENTAL: float = 0.20    # 基本面估值
    WEIGHT_SENTIMENT: float = 0.15      # 舆情公告

    # ---------- 安全阈值 ----------
    MIN_TOTAL_SCORE: float = 60.0       # 综合总分低于此值不入选

    def __init__(self):
        pass

    # ----------------------------------------------------------------
    # 因子1：资金流向打分（0~100）
    # ----------------------------------------------------------------

    def score_fund_flow(self, symbol: str, stock_row: pd.Series,
                        fund_df: Optional[pd.DataFrame]) -> Tuple[float, str]:
        """
        资金流向因子打分

        判断逻辑：
          - 主力净流入额排名全市场前20% → 高分
          - 大单买入占比高 → 加分
          - 资金持续多日净流入 → 加分
        """
        score = 50.0   # 基准分
        reasons = []

        # ---- 从资金流DataFrame获取数据 ----
        if fund_df is not None and len(fund_df) > 0:
            sym_in_fund = fund_df[fund_df['symbol'] == symbol] if 'symbol' in fund_df.columns else pd.DataFrame()
            if len(sym_in_fund) > 0:
                row = sym_in_fund.iloc[0]
                main_inflow = float(row.get('main_net_inflow', 0))
                main_inflow_pct = float(row.get('main_net_inflow_pct', 0))

                # 主力净流入额评分（正值加分，负值扣分）
                if main_inflow > 10_000_000:   # >1000万
                    score += 25
                    reasons.append(f"主力净流入{main_inflow/1e4:.0f}万，资金积极流入")
                elif main_inflow > 1_000_000:
                    score += 15
                    reasons.append(f"主力净流入{main_inflow/1e4:.0f}万，小幅流入")
                elif main_inflow > -1_000_000:
                    score += 5
                    reasons.append("主力资金基本平衡")
                else:
                    score -= 15
                    reasons.append(f"主力净流出{abs(main_inflow)/1e4:.0f}万，资金承压")

                # 净占比评分
                if main_inflow_pct > 5:
                    score += 15
                    reasons.append(f"大单净占比{main_inflow_pct:.1f}%，主力积极介入")
                elif main_inflow_pct > 0:
                    score += 8
                elif main_inflow_pct < -5:
                    score -= 10
                    reasons.append(f"大单净占比{main_inflow_pct:.1f}%，主力撤退迹象")
            else:
                reasons.append("未获取到资金流数据，按中性处理")
        else:
            # 无资金流数据，用成交额/量比做代理判断
            amount = float(stock_row.get('amount', 0))
            volume_ratio = float(stock_row.get('volume_ratio', 1.0))
            if volume_ratio > 1.5:
                score += 10
                reasons.append(f"量比{volume_ratio:.1f}，放量明显")
            elif volume_ratio < 0.5:
                score -= 5
            reasons.append("资金流数据暂缺，以量价代理评估")

        # ---- 从stock行情数据获取补充信息 ----
        pct_chg = float(stock_row.get('pct_chg', 0))
        if 0 < pct_chg < 5:
            score += 5
            reasons.append(f"日内涨幅{pct_chg:.2f}%，温和上涨")
        elif pct_chg >= 5:
            score += 3
            reasons.append(f"日内涨幅{pct_chg:.2f}%，涨幅较大注意追高风险")

        return max(0, min(100, score)), '; '.join(reasons) if reasons else '无特殊资金信号'

    # ----------------------------------------------------------------
    # 因子2：技术行情打分（0~100）
    # ----------------------------------------------------------------

    def score_technical(self, symbol: str, stock_row: pd.Series) -> Tuple[float, str]:
        """
        技术行情因子打分

        判断逻辑：
          - 短期均线（5/10日）多头排列
          - 股价站稳均线上方
          - 日内开盘小幅高开无跳水
          - 近几日震荡上行趋势
          - 振幅适中（无剧烈暴跌暴涨）
        """
        score = 50.0
        reasons = []

        pct_chg = float(stock_row.get('pct_chg', 0))
        amplitude = float(stock_row.get('amplitude', 0))
        open_p = float(stock_row.get('open', 0))
        pre_close = float(stock_row.get('pre_close', 0))
        latest = float(stock_row.get('latest_price', 0))
        high = float(stock_row.get('high', 0))
        low = float(stock_row.get('low', 0))

        # ---- 日内涨跌态势 ----
        if pct_chg > 0:
            if pct_chg < 3:
                score += 12
                reasons.append(f"日内涨{pct_chg:.2f}%，稳定上行")
            elif pct_chg < 7:
                score += 8
                reasons.append(f"日内涨{pct_chg:.2f}%，走势偏强")
            else:
                score += 3
                reasons.append(f"日内涨{pct_chg:.2f}%，涨幅过大短期回调风险")
        elif pct_chg > -2:
            score += 5
            reasons.append(f"日内微跌{pct_chg:.2f}%，横盘整理")
        else:
            score -= 10
            reasons.append(f"日内跌{abs(pct_chg):.2f}%，弱势下行")

        # ---- 振幅评估（振幅过大说明分歧剧烈，日内短线应避开）----
        if amplitude < 3:
            score += 10
            reasons.append(f"振幅{amplitude:.2f}%，走势平稳")
        elif amplitude < 6:
            score += 5
            reasons.append(f"振幅{amplitude:.2f}%，波动适中")
        elif amplitude < 10:
            score += 0
            reasons.append(f"振幅{amplitude:.2f}%，波动偏大")
        else:
            score -= 10
            reasons.append(f"振幅{amplitude:.2f}%，剧烈波动风险高")

        # ---- 开盘形态 ----
        if pre_close > 0 and open_p > 0:
            open_chg = (open_p - pre_close) / pre_close * 100
            if 0 <= open_chg < 3:
                score += 10
                reasons.append(f"开盘{open_chg:+.2f}%，小幅高开无跳水")
            elif open_chg >= 3:
                score += 5
                reasons.append(f"开盘{open_chg:+.2f}%，大幅高开注意回落")
            elif open_chg > -1:
                score += 5
                reasons.append("平开/微低开，稳健")
            elif open_chg > -3:
                score += 2
                reasons.append(f"开盘{open_chg:+.2f}%，低开需关注")
            else:
                score -= 8
                reasons.append(f"开盘{open_chg:+.2f}%，大幅低开弱势")

        # ---- 日内形态（收盘价相对开盘价的方向）----
        if open_p > 0 and latest > 0:
            intra_trend = (latest - open_p) / open_p * 100
            if intra_trend > 1:
                score += 5
                reasons.append("日内低开高走/持续上行")
            elif intra_trend < -2:
                score -= 5
                reasons.append("日内冲高回落")

        # ---- 高低点位置（收盘价在日内区间的相对位置）----
        if high > low > 0 and latest > 0:
            position_in_range = (latest - low) / (high - low) if (high - low) > 0 else 0.5
            if position_in_range > 0.7:
                score += 3
                reasons.append("收盘于日内高位，多头占优")
            elif position_in_range < 0.3:
                score -= 5
                reasons.append("收盘于日内低位，空头占优")

        return max(0, min(100, score)), '; '.join(reasons) if reasons else '技术指标中性'

    # ----------------------------------------------------------------
    # 因子3：基本面估值打分（0~100）
    # ----------------------------------------------------------------

    def score_fundamental(self, symbol: str, stock_row: pd.Series,
                          fin_df: Optional[pd.DataFrame]) -> Tuple[float, str]:
        """
        基本面估值因子打分

        判断逻辑：
          - PE市盈率处于合理区间（不同行业差异大，给出容差）
          - ROE为正值
          - 季度营收/净利润正向增长
          - 无大额商誉暴雷 / 质押风险低
        """
        score = 50.0
        reasons = []

        # ---- 从stock行情自带PE ----
        pe = float(stock_row.get('pe_dynamic', 0))
        pb = float(stock_row.get('pb', 0))
        total_mv = float(stock_row.get('total_mv', 0))

        if pe > 0:
            if pe < 20:
                score += 15
                reasons.append(f"PE={pe:.1f}，估值合理偏低")
            elif pe < 50:
                score += 10
                reasons.append(f"PE={pe:.1f}，估值适中")
            elif pe < 100:
                score += 3
                reasons.append(f"PE={pe:.1f}，估值偏高")
            else:
                score -= 5
                reasons.append(f"PE={pe:.1f}，估值过高")
        else:
            # PE为负（亏损），细分情况
            if pe < -50:
                score -= 15
                reasons.append("公司大额亏损，基本面较差")
            else:
                score -= 5
                reasons.append("公司微亏或PE异常")

        # ---- PB ----
        if 0 < pb < 3:
            score += 5
            reasons.append(f"PB={pb:.2f}，市净率合理")
        elif pb >= 5:
            score -= 3

        # ---- 从财务数据获取 ----
        if fin_df is not None and len(fin_df) > 0:
            sym_in_fin = fin_df[fin_df['symbol'] == symbol] if 'symbol' in fin_df.columns else pd.DataFrame()
            if len(sym_in_fin) > 0:
                row = sym_in_fin.iloc[0]
                roe = float(row.get('roe', 0))
                net_profit = float(row.get('net_profit', 0))

                if roe > 15:
                    score += 10
                    reasons.append(f"ROE={roe:.1f}%，盈利能力优秀")
                elif roe > 5:
                    score += 6
                    reasons.append(f"ROE={roe:.1f}%，盈利良好")
                elif roe > 0:
                    score += 3
                    reasons.append("ROE为正，基本盈利")
                else:
                    score -= 5
                    reasons.append("ROE为负")

                if net_profit > 1e8:
                    score += 5
                    reasons.append(f"净利润{net_profit/1e8:.1f}亿，业绩扎实")
                elif net_profit > 0:
                    score += 2
            else:
                reasons.append("未获取到详细财务数据")
        else:
            reasons.append("财务数据暂缺，以PE/PB代理评估")

        # ---- 市值（大盘股更稳健）----
        if total_mv > 1e11:   # >1000亿
            score += 5
            reasons.append("大盘蓝筹，流动性好")
        elif total_mv > 1e10:  # >100亿
            score += 3
            reasons.append("中盘股")
        elif total_mv < 2e9:   # <20亿
            score -= 5
            reasons.append("小盘股流动性风险")

        return max(0, min(100, score)), '; '.join(reasons) if reasons else '基本面数据有限'

    # ----------------------------------------------------------------
    # 因子4：舆情公告打分（0~100）
    # ----------------------------------------------------------------

    def score_sentiment(self, symbol: str, stock_row: pd.Series,
                        news_sentiment: Dict[str, int]) -> Tuple[float, str]:
        """
        舆情公告因子打分

        判断逻辑：
          - 当日正面利好公告（订单、预增、政策、回购）
          - 全网财经新闻正面舆情数量 > 负面
          - 无监管问询/减持/亏损利空
        """
        score = 50.0
        reasons = []

        if symbol in news_sentiment:
            sent = news_sentiment[symbol]
            if sent > 3:
                score += 25
                reasons.append(f"正面舆情得分{sent}，多条利好消息")
            elif sent > 1:
                score += 15
                reasons.append(f"正面舆情得分{sent}，偏利好")
            elif sent > 0:
                score += 8
                reasons.append(f"舆情得分{sent}，中性偏正")
            elif sent == 0:
                score += 0
                reasons.append("舆情中性，无显著消息")
            elif sent > -3:
                score -= 8
                reasons.append(f"舆情得分{sent}，有少量负面消息")
            else:
                score -= 20
                reasons.append(f"舆情得分{sent}，负面消息较多")
        else:
            reasons.append("未匹配到相关新闻舆情")

        # ---- 从股票数据看潜在利好/利空信号 ----
        pct_chg_60d = float(stock_row.get('pct_chg_60d', 0))
        if pct_chg_60d > 30:
            score += 3
            reasons.append("近60日涨幅显著，市场认可度高")
        elif pct_chg_60d < -20:
            score -= 5
            reasons.append("近60日跌幅较大，可能存在未披露利空")

        return max(0, min(100, score)), '; '.join(reasons) if reasons else '无明确舆情信号'

    # ----------------------------------------------------------------
    # 综合打分
    # ----------------------------------------------------------------

    def compute_total_score(
        self, symbol: str, stock_row: pd.Series,
        fund_df: Optional[pd.DataFrame],
        fin_df: Optional[pd.DataFrame],
        news_sentiment: Dict[str, int]
    ) -> Dict:
        """
        综合四大因子计算总分

        返回完整的打分字典，包含各因子得分和归因文本
        """
        fund_score, fund_reason = self.score_fund_flow(symbol, stock_row, fund_df)
        tech_score, tech_reason = self.score_technical(symbol, stock_row)
        fin_score, fin_reason = self.score_fundamental(symbol, stock_row, fin_df)
        sent_score, sent_reason = self.score_sentiment(symbol, stock_row, news_sentiment)

        total = (
            fund_score * self.WEIGHT_FUND_FLOW +
            tech_score * self.WEIGHT_TECHNICAL +
            fin_score * self.WEIGHT_FUNDAMENTAL +
            sent_score * self.WEIGHT_SENTIMENT
        )

        return {
            'symbol': symbol,
            'name': str(stock_row.get('name', symbol)),
            'pre_close': float(stock_row.get('pre_close', 0)),
            'latest_price': float(stock_row.get('latest_price', 0)),
            'pct_chg': float(stock_row.get('pct_chg', 0)),
            # 因子得分
            'fund_flow_score': round(fund_score, 1),
            'technical_score': round(tech_score, 1),
            'fundamental_score': round(fin_score, 1),
            'sentiment_score': round(sent_score, 1),
            'total_score': round(total, 1),
            # 归因文本
            'fund_flow_reason': fund_reason,
            'technical_reason': tech_reason,
            'fundamental_reason': fin_reason,
            'sentiment_reason': sent_reason,
            # 权重信息（记录用）
            'weights': {
                'fund_flow': self.WEIGHT_FUND_FLOW,
                'technical': self.WEIGHT_TECHNICAL,
                'fundamental': self.WEIGHT_FUNDAMENTAL,
                'sentiment': self.WEIGHT_SENTIMENT,
            }
        }


# ============================================================================
# 选股归因文本生成器
# ============================================================================

class AttributionGenerator:
    """
    归因文本生成器

    为每只入选股票生成标准化归因说明：
      1. 标的基础信息
      2. 得分拆解（四大因子得分 + 总分排名）
      3. 买入标的理由（利好支撑点 + 风险提示）
      4. 买入股数分配理由（资金计算明细）
      5. 整体仓位分散理由
    """

    def __init__(self):
        pass

    def generate_stock_attribution(
        self,
        score_dict: Dict,
        position: Dict,
        available_capital: int,
        total_stocks: int,
        rank: int
    ) -> str:
        """
        单只股票完整归因说明
        """
        sym = score_dict['symbol']
        name = score_dict['name']
        pre_close = score_dict['pre_close']
        total_score = score_dict['total_score']

        vol = position.get('volume', 0)
        lots = position.get('lots', 0)
        cost = position.get('cost', 0)
        cost_ratio = position.get('cost_ratio', 0)
        one_lot_cost = position.get('one_lot_cost', 0)
        max_lots = position.get('max_lots', 0)

        single_stock_cap = int(available_capital * 0.15)

        lines = []
        lines.append("─" * 50)
        lines.append(f"【{name}】({sym}) 选股+仓位归因报告")
        lines.append("")

        # ---- 1. 标的基础信息 ----
        lines.append("1. 标的基础信息")
        lines.append(f"   股票代码: {sym}")
        lines.append(f"   股票简称: {name}")
        lines.append(f"   昨日收盘价: {pre_close:.2f}元")
        lines.append(f"   1手(100股)成本: {one_lot_cost:,}元")
        lines.append(f"   日内涨跌幅: {score_dict.get('pct_chg',0):+.2f}%")
        lines.append("")

        # ---- 2. 得分拆解 ----
        lines.append("2. 四大因子得分拆解")
        lines.append(f"   资金流向因子 (权重{score_dict['weights']['fund_flow']*100:.0f}%): {score_dict['fund_flow_score']:.1f}分")
        lines.append(f"     → {score_dict['fund_flow_reason']}")
        lines.append(f"   技术行情因子 (权重{score_dict['weights']['technical']*100:.0f}%): {score_dict['technical_score']:.1f}分")
        lines.append(f"     → {score_dict['technical_reason']}")
        lines.append(f"   基本面估值因子 (权重{score_dict['weights']['fundamental']*100:.0f}%): {score_dict['fundamental_score']:.1f}分")
        lines.append(f"     → {score_dict['fundamental_reason']}")
        lines.append(f"   舆情公告因子 (权重{score_dict['weights']['sentiment']*100:.0f}%): {score_dict['sentiment_score']:.1f}分")
        lines.append(f"     → {score_dict['sentiment_reason']}")
        lines.append(f"   ★ 综合总分: {total_score:.1f}分（排名第{rank}位）")
        lines.append("")

        # ---- 3. 买入理由 + 风险 ----
        lines.append("3. 买入标的理由与风险提示")
        # 收集利好点
        positives = []
        risks = []
        for factor, label in [
            ('fund_flow_reason', '【资金面】'),
            ('technical_reason', '【技术面】'),
            ('fundamental_reason', '【基本面】'),
            ('sentiment_reason', '【舆情面】')
        ]:
            reason = score_dict.get(factor, '')
            if reason and '风险' not in reason and '承压' not in reason and '偏弱' not in reason:
                positives.append(f"   {label} {reason}")
            elif reason:
                risks.append(f"   {label} {reason}")

        if positives:
            lines.append("   利好支撑:")
            for p in positives[:5]:  # 至多5条
                lines.append(p)
        if risks:
            lines.append("   风险提示:")
            for r in risks[:3]:
                lines.append(r)
        if not positives and not risks:
            lines.append("   无明显利好或利空信号")
        lines.append("")

        # ---- 4. 股数分配理由 ----
        lines.append("4. 买入股数（volume）分配理由")
        lines.append(f"   当日总可用资金: {available_capital:,}元")
        lines.append(f"   单票上限15%即: {single_stock_cap:,}元")
        lines.append(f"   1手成本: {one_lot_cost:,}元")
        lines.append(f"   理论最大可买: {max_lots}手（{max_lots*100}股）")
        lines.append(f"   本次实际分配: {lots}手（{vol}股）")
        lines.append(f"   占用资金: {cost:,}元")
        lines.append(f"   占当日可用资金: {cost_ratio:.1f}%")
        lines.append("")

        # ---- 5. 分散理由 ----
        lines.append("5. 整体仓位分散理由")
        lines.append(f"   今日共选{total_stocks}只股票，通过分散持仓降低单一个股波动亏损风险")
        lines.append(f"   各单票上限15%，总仓位上限90%，预留10%现金缓冲")
        lines.append("─" * 50)

        return '\n'.join(lines)

    def generate_daily_summary(
        self,
        positions: List[Dict],
        available_capital: int,
        total_cost: int,
        n_candidates: int
    ) -> str:
        """
        每日投资组合整体归因总结
        """
        lines = []
        lines.append("=" * 60)
        lines.append("【驼灵智能体大赛 - 日度选股总结】")
        lines.append(f"可用资金: {available_capital:,}元")
        lines.append(f"全市场合规标的: {n_candidates}只")
        lines.append(f"今日选股: {len(positions)}只")
        if len(positions) > 0:
            lines.append(f"总买入占用: {total_cost:,}元 ({total_cost/available_capital*100:.1f}%)")
            lines.append(f"现金缓冲: {available_capital - total_cost:,}元")
        else:
            lines.append("今日空仓观望（无达标标的）")
        lines.append("")
        if positions:
            for i, pos in enumerate(positions, 1):
                lines.append(f"  {i}. {pos['name']}({pos['symbol']}) | "
                             f"得分{pos.get('score','N/A')} | "
                             f"{pos['lots']}手 {pos['volume']}股 | "
                             f"成本{pos['cost']:,}元")
        lines.append("=" * 60)
        return '\n'.join(lines)


# ============================================================================
# 选股主引擎
# ============================================================================

class StockSelectionEngine:
    """
    选股引擎 —— 多因子打分 + 筛选 + 归因生成一站式
    """

    def __init__(self):
        self.scorer = FactorScorer()
        self.attribution = AttributionGenerator()

    def score_all_stocks(
        self,
        stock_df: pd.DataFrame,
        fund_df: Optional[pd.DataFrame],
        fin_df: Optional[pd.DataFrame],
        news_sentiment: Dict[str, int]
    ) -> List[Dict]:
        """
        对全市场合规标的逐一打分

        返回按总分降序排列的选股结果列表
        """
        results = []
        logger.info(f">>> 开始对 {len(stock_df)} 只标的进行多因子打分...")

        for idx, row in stock_df.iterrows():
            sym = row['symbol']
            score_dict = self.scorer.compute_total_score(
                sym, row, fund_df, fin_df, news_sentiment
            )
            results.append(score_dict)

        # 按总分降序排列
        results.sort(key=lambda x: x['total_score'], reverse=True)

        # 统计分数分布
        high = sum(1 for r in results if r['total_score'] >= 70)
        mid = sum(1 for r in results if 60 <= r['total_score'] < 70)
        low = sum(1 for r in results if r['total_score'] < 60)
        logger.info(f"    打分完成 | 高分(≥70): {high}只 | 中分(60-70): {mid}只 | 低分(<60): {low}只")

        return results

    def select_stocks(
        self,
        stock_df: pd.DataFrame,
        fund_df: Optional[pd.DataFrame],
        fin_df: Optional[pd.DataFrame],
        news_sentiment: Dict[str, int],
        min_score: float = 60.0,
        max_picks: int = 8
    ) -> List[Dict]:
        """
        筛选高分达标标的

        参数:
          stock_df: 全市场合规标的DataFrame
          fund_df: 资金流数据
          fin_df: 财务数据
          news_sentiment: 舆情字典
          min_score: 最低综合分阈值
          max_picks: 最多选股数量

        返回:
          达标选股结果列表（已排序）
        """
        # 先打分
        all_scores = self.score_all_stocks(stock_df, fund_df, fin_df, news_sentiment)

        # 筛选达标标的
        qualified = [s for s in all_scores if s['total_score'] >= min_score]
        logger.info(f"    min_score={min_score}阈值以上: {len(qualified)}只")

        # 兜底逻辑：高质量标的不足3只时，有几只买几只（不强行凑劣质票）
        if len(qualified) == 0:
            logger.warning(">>> 全市场无达标标的（所有个股综合得分 < %.1f），今日空仓观望 <<<", min_score)
            return []
        elif len(qualified) < 3:
            logger.info(f"    达标标的仅{len(qualified)}只（不足3只），按实际数量选入")

        # 截取top N
        picks = qualified[:min(len(qualified), max_picks)]
        # 赋予排名
        for i, pick in enumerate(picks, 1):
            pick['rank'] = i

        return picks


# ============================================================================
# 自测 Demo
# ============================================================================

def demo_test():
    """
    内置测试Demo——模拟选股打分+归因全流程
    """
    print("\n" + "=" * 60)
    print("策略核心 Demo 测试 —— 选股打分+归因")
    print("=" * 60)

    # 模拟股票数据
    import pandas as pd
    mock_stocks = pd.DataFrame([
        {'symbol': '600036', 'name': '招商银行', 'latest_price': 30.50, 'pre_close': 30.00,
         'pct_chg': 1.67, 'open': 30.10, 'high': 30.80, 'low': 29.90,
         'amplitude': 3.0, 'amount': 3.5e9, 'volume_ratio': 1.2,
         'pe_dynamic': 6.5, 'pb': 0.9, 'total_mv': 7.5e11, 'pct_chg_60d': 5.2},
        {'symbol': '002594', 'name': '比亚迪', 'latest_price': 248.00, 'pre_close': 250.00,
         'pct_chg': -0.80, 'open': 249.00, 'high': 252.00, 'low': 246.00,
         'amplitude': 2.4, 'amount': 2.8e9, 'volume_ratio': 0.9,
         'pe_dynamic': 28.0, 'pb': 6.5, 'total_mv': 7.2e11, 'pct_chg_60d': -3.1},
        {'symbol': '000725', 'name': '京东方A', 'latest_price': 4.08, 'pre_close': 4.00,
         'pct_chg': 2.00, 'open': 4.02, 'high': 4.10, 'low': 4.00,
         'amplitude': 2.5, 'amount': 1.5e9, 'volume_ratio': 1.5,
         'pe_dynamic': 35.0, 'pb': 1.3, 'total_mv': 1.5e11, 'pct_chg_60d': 12.0},
    ])

    # 模拟资金流
    mock_fund = pd.DataFrame([
        {'symbol': '600036', 'main_net_inflow': 15000000, 'main_net_inflow_pct': 4.2},
        {'symbol': '002594', 'main_net_inflow': -5000000, 'main_net_inflow_pct': -1.8},
        {'symbol': '000725', 'main_net_inflow': 8000000, 'main_net_inflow_pct': 3.5},
    ])

    # 模拟财务
    mock_fin = pd.DataFrame([
        {'symbol': '600036', 'roe': 16.5, 'net_profit': 1.48e10, 'revenue': 8.5e10},
        {'symbol': '002594', 'roe': 22.0, 'net_profit': 3.0e9, 'revenue': 1.8e11},
        {'symbol': '000725', 'roe': 8.2, 'net_profit': 5.0e8, 'revenue': 5.5e10},
    ])

    # 模拟舆情
    mock_news = {'600036': 2, '002594': -1, '000725': 3}

    engine = StockSelectionEngine()
    picks = engine.select_stocks(mock_stocks, mock_fund, mock_fin, mock_news, min_score=60.0)

    print(f"\n达标选股: {len(picks)} 只\n")

    # 模拟仓位分配
    from capital_manager import CapitalManager
    cm = CapitalManager(initial_capital=500_000)
    cm.new_trading_day('20260101')
    pre_closes = {s['symbol']: s['pre_close'] for s in picks}
    positions = cm.allocate_positions(picks, pre_closes)

    # 生成归因
    attr_gen = AttributionGenerator()
    for i, pick in enumerate(picks, 1):
        pos = next((p for p in positions if p['symbol'] == pick['symbol']), None)
        if pos:
            attr_text = attr_gen.generate_stock_attribution(
                pick, pos, cm.available_capital, len(positions), i
            )
            print(attr_text)
            print()

    # 日度总结
    total_cost = sum(p['cost'] for p in positions)
    summary = attr_gen.generate_daily_summary(
        positions, cm.available_capital, total_cost, 3
    )
    print(summary)


if __name__ == '__main__':
    demo_test()
