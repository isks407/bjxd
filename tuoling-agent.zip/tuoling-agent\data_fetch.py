"""
本程序仅用于驼灵智能体大赛学术模拟，不构成真实市场投资建议。
data_fetch.py —— AKShare 数据封装拉取、清洗、过滤工具类
负责：拉取全A股行情、资金流、财务、新闻数据；过滤停牌/ST/退市/流动性差标的
"""

import akshare as ak
import pandas as pd
import numpy as np
import logging
import time
from datetime import datetime, timedelta
from typing import Tuple, List, Optional, Dict

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)


# ============================================================================
# 辅助工具函数
# ============================================================================

def _safe_float(val, default=0.0) -> float:
    """安全转换为浮点数，转换失败返回默认值（规避脏数据报错）"""
    try:
        v = float(val)
        return v if not np.isnan(v) and not np.isinf(v) else default
    except (ValueError, TypeError):
        return default


def _safe_int(val, default=0) -> int:
    """安全转换为整数"""
    try:
        return int(float(val))
    except (ValueError, TypeError):
        return default


def _to_six_digit(code: str) -> str:
    """统一将股票代码格式化为6位数字字符串，不足6位左侧补零"""
    code = str(code).strip().replace("'", "").replace('"', '')
    # 处理 sh600000 / sz000001 格式
    if '.' in code:
        code = code.split('.')[-1]
    return code.zfill(6)


# ============================================================================
# 数据拉取核心类
# ============================================================================

class AStockDataFetcher:
    """
    AKShare A股数据拉取器
    - 获取全A股实时/历史行情
    - 拉取资金流（主力净流入等）
    - 拉取财务基本面（PE/ROE/净利润等）
    - 拉取财经新闻舆情
    - 过滤废标（ST/停牌/退市/无量/一字跌停）
    """

    def __init__(self):
        self.stock_list: Optional[pd.DataFrame] = None       # 全A股基础信息
        self.daily_quotes: Optional[pd.DataFrame] = None     # 当日行情
        self.yesterday_close: Dict[str, float] = {}          # 昨收价字典 {symbol: close}
        self.fund_flow: Optional[pd.DataFrame] = None        # 资金流数据
        self.financials: Optional[pd.DataFrame] = None       # 财务数据
        self.news_sentiment: Dict[str, int] = {}             # 舆情得分 {symbol: score}

        # ---------- 涨跌幅限制映射（主板±10%、创业板±20%、科创板±20%、ST±5%）----------
        # 上证主板 600/601/603/605；深证主板 000/001/002；创业板 300/301；科创板 688
        self.limit_up_down: Dict[str, Tuple[float, float]] = {}  # {symbol: (limit_down%, limit_up%)}

    # ------------------------------------------------------------------
    # 1. 拉取全A股股票列表 & 基础过滤
    # ------------------------------------------------------------------

    def fetch_stock_list(self) -> pd.DataFrame:
        """
        拉取全A股股票基础信息，初步过滤：
        - 剔除ST、*ST、退市整理
        - 剔除B股（9开头）
        - 剔除北交所（8开头，流动性差）
        保留：沪主板(6)、深主板(0/2)、创业板(3)、科创板(688)
        """
        logger.info(">>> 正在拉取全A股股票列表...")
        try:
            # AKShare 获取沪深京A股实时行情数据（含股票代码、名称、最新价等）
            df = ak.stock_zh_a_spot_em()
            logger.info(f"    原始拉取 {len(df)} 只标的")
        except Exception as e:
            logger.error(f"    拉取股票列表失败: {e}")
            # 降级尝试备用接口
            try:
                df = ak.stock_zh_a_spot()
                logger.info(f"    备用接口拉取 {len(df)} 只标的")
            except Exception as e2:
                logger.error(f"    备用接口也失败: {e2}")
                return pd.DataFrame()

        # 统一列名处理
        col_map = {
            '代码': 'symbol', '名称': 'name',
            '最新价': 'latest_price', '涨跌幅': 'pct_chg',
            '涨跌额': 'change', '成交量': 'volume', '成交额': 'amount',
            '振幅': 'amplitude', '最高': 'high', '最低': 'low',
            '今开': 'open', '昨收': 'pre_close',
            '量比': 'volume_ratio', '换手率': 'turnover_rate',
            '市盈率-动态': 'pe_dynamic', '市净率': 'pb',
            '总市值': 'total_mv', '流通市值': 'circ_mv',
            '60日涨跌幅': 'pct_chg_60d', '年初至今涨跌幅': 'pct_chg_ytd',
        }
        df = df.rename(columns={k: v for k, v in col_map.items() if k in df.columns})

        # ---------- 代码清洗 ----------
        if 'symbol' in df.columns:
            df['symbol'] = df['symbol'].apply(_to_six_digit)
        else:
            logger.error("    未找到股票代码列，无法继续")
            return pd.DataFrame()

        # ---------- 剔除 ST / *ST / 退市 ----------
        if 'name' in df.columns:
            mask_st = df['name'].str.contains(r'ST|退市|退', na=False)
            df = df[~mask_st]
            logger.info(f"    剔除ST/退市后剩余 {len(df)} 只")

        # ---------- 剔除北交所（8开头）& B股（9开头）----------
        df = df[~df['symbol'].str.match(r'^[89]')]
        logger.info(f"    剔除北交所/B股后剩余 {len(df)} 只")

        # ---------- 过滤停牌（成交额为0或价格为0的标的）----------
        if 'amount' in df.columns:
            df = df[df['amount'] > 0]
        if 'latest_price' in df.columns:
            df = df[df['latest_price'] > 0]
        logger.info(f"    剔除停牌/零成交后剩余 {len(df)} 只")

        self.stock_list = df.reset_index(drop=True)

        # ---------- 构建昨收价字典 ----------
        if 'pre_close' in df.columns:
            self.yesterday_close = dict(zip(df['symbol'], df['pre_close']))
        elif 'latest_price' in df.columns:
            # 如果无昨收数据，用最新价近似（回退策略）
            self.yesterday_close = dict(zip(df['symbol'], df['latest_price']))

        # ---------- 设置涨跌幅限制 ----------
        self._set_limit_up_down()

        return self.stock_list

    def _set_limit_up_down(self):
        """根据股票代码自动设置涨跌幅限制"""
        if self.stock_list is None:
            return
        for _, row in self.stock_list.iterrows():
            sym = row['symbol']
            name = str(row.get('name', ''))
            # ST类股票 ±5%
            if 'ST' in name or '*ST' in name:
                self.limit_up_down[sym] = (-5.0, 5.0)
            # 创业板 300/301
            elif sym.startswith('30'):
                self.limit_up_down[sym] = (-20.0, 20.0)
            # 科创板 688
            elif sym.startswith('688'):
                self.limit_up_down[sym] = (-20.0, 20.0)
            # 主板 600/601/603/605/000/001/002/003
            else:
                self.limit_up_down[sym] = (-10.0, 10.0)

    # ------------------------------------------------------------------
    # 2. 流动性过滤（近20日日均成交额 > 2亿）
    # ------------------------------------------------------------------

    def filter_by_liquidity(self) -> pd.DataFrame:
        """
        流动性筛选：剔除近20日日均成交额 < 2亿的冷门股
        返回通过筛选的股票DataFrame
        """
        if self.stock_list is None or len(self.stock_list) == 0:
            logger.warning("    股票列表为空，跳过流动性筛选")
            return pd.DataFrame()

        logger.info(">>> 正在执行流动性筛选（20日均额>2亿）...")
        symbols = self.stock_list['symbol'].tolist()
        qualified = []

        batch_size = 50  # 每批拉取50只，避免频率限制
        for i in range(0, len(symbols), batch_size):
            batch = symbols[i:i + batch_size]
            for sym in batch:
                try:
                    # 拉取近30日历史日K数据
                    hist = ak.stock_zh_a_hist(
                        symbol=sym,
                        period='daily',
                        start_date=(datetime.now() - timedelta(days=60)).strftime('%Y%m%d'),
                        end_date=datetime.now().strftime('%Y%m%d'),
                        adjust='qfq'  # 前复权
                    )
                    if hist is None or len(hist) < 5:
                        continue
                    # 取近20个交易日（如不足20天则取全部）
                    recent = hist.tail(20)
                    avg_amount = recent['成交额'].mean()
                    if avg_amount >= 200_000_000:  # 2亿 = 200,000,000
                        qualified.append(sym)
                except Exception as e:
                    logger.debug(f"    拉取{sym}历史数据异常: {e}")
                    continue
            time.sleep(0.3)  # 适当延时避免被封IP

        logger.info(f"    流动性筛选通过 {len(qualified)} 只标的（原始{len(symbols)}只）")
        self.stock_list = self.stock_list[self.stock_list['symbol'].isin(qualified)].reset_index(drop=True)
        return self.stock_list

    def filter_liquidity_fast(self) -> pd.DataFrame:
        """
        流动性快速筛选（使用实时成交额作为代理指标）
        避免逐只拉取历史K线的耗时操作
        规则：当日成交额>5000万 且 换手率>0.5%
        """
        if self.stock_list is None or len(self.stock_list) == 0:
            return pd.DataFrame()

        logger.info(">>> 正在执行快速流动性筛选...")
        df = self.stock_list
        if 'amount' in df.columns:
            df = df[df['amount'] >= 50_000_000]  # 当日成交额>5000万
        if 'turnover_rate' in df.columns:
            df = df[df['turnover_rate'] >= 0.5]   # 换手率>0.5%
        self.stock_list = df.reset_index(drop=True)
        logger.info(f"    快速流动性筛选后剩余 {len(self.stock_list)} 只")
        return self.stock_list

    # ------------------------------------------------------------------
    # 3. 涨跌幅风险过滤（剔除一字跌停/暴跌标的）
    # ------------------------------------------------------------------

    def filter_price_limit_risk(self) -> pd.DataFrame:
        """
        涨幅风险过滤：
        - 剔除当日跌幅接近跌停板的标的（疑似暴雷/利空）
        - 剔除开盘一字跌停（开盘价≈跌停价）
        保留阈值：当日跌幅 > limit_down + 2%（给出2%容差）
        """
        if self.stock_list is None or len(self.stock_list) == 0:
            return pd.DataFrame()

        logger.info(">>> 正在执行涨跌幅风险过滤...")
        df = self.stock_list
        drop_symbols = []

        for _, row in df.iterrows():
            sym = row['symbol']
            pct = _safe_float(row.get('pct_chg', 0))
            limit_down, limit_up = self.limit_up_down.get(sym, (-10.0, 10.0))

            # 如果跌幅接近跌停板（容差2%），剔除
            if pct <= limit_down + 2.0:
                drop_symbols.append(sym)
                logger.info(f"    剔除 {sym} {row.get('name','')}: 跌幅{pct:.2f}% 接近跌停")

            # 检查是否一字跌停（开盘价≈最低价≈跌停价，且成交极小）
            open_p = _safe_float(row.get('open', 0))
            low_p = _safe_float(row.get('low', 0))
            pre_p = _safe_float(row.get('pre_close', 1))
            if pre_p > 0 and open_p > 0:
                if (pre_p - open_p) / pre_p * 100 >= abs(limit_down) - 0.5:
                    # 开盘即接近跌停
                    drop_symbols.append(sym)

        df = df[~df['symbol'].isin(drop_symbols)]
        self.stock_list = df.reset_index(drop=True)
        logger.info(f"    涨跌幅过滤后剩余 {len(self.stock_list)} 只")
        return self.stock_list

    # ------------------------------------------------------------------
    # 4. 资金流数据拉取
    # ------------------------------------------------------------------

    def fetch_fund_flow(self) -> pd.DataFrame:
        """
        拉取个股资金流向数据
        核心指标：主力净流入额（近1/3/5日）、大单买入占比
        """
        logger.info(">>> 正在拉取资金流向数据...")
        try:
            # AKShare 个股资金流向（当日）
            df = ak.stock_individual_fund_flow(stock='', market='sh')
            if df is None or len(df) == 0:
                # 尝试沪深全市场资金流排名
                df = ak.stock_market_fund_flow()
        except Exception as e:
            logger.warning(f"    资金流拉取失败: {e}")
            return pd.DataFrame()

        # 尝试获取个股资金流
        fund_records = []
        if self.stock_list is not None and len(self.stock_list) <= 100:
            for _, row in self.stock_list.iterrows():
                sym = row['symbol']
                try:
                    flow = ak.stock_individual_fund_flow(stock=sym, market='sh' if sym.startswith('6') else 'sz')
                    if flow is not None and len(flow) > 0:
                        latest = flow.iloc[-1]
                        fund_records.append({
                            'symbol': sym,
                            'main_net_inflow': _safe_float(latest.get('主力净流入-净额', 0)),
                            'main_net_inflow_pct': _safe_float(latest.get('主力净流入-净占比', 0)),
                            'super_large_net_inflow': _safe_float(latest.get('超大单净流入-净额', 0)),
                            'large_net_inflow': _safe_float(latest.get('大单净流入-净额', 0)),
                            'mid_net_inflow': _safe_float(latest.get('中单净流入-净额', 0)),
                            'small_net_inflow': _safe_float(latest.get('小单净流入-净额', 0)),
                        })
                except Exception:
                    continue
                time.sleep(0.15)

        self.fund_flow = pd.DataFrame(fund_records) if fund_records else pd.DataFrame()
        logger.info(f"    获取到 {len(self.fund_flow)} 只标的资金流数据")
        return self.fund_flow

    def fetch_fund_flow_ranking(self) -> pd.DataFrame:
        """
        备选方案：通过AKShare全市场资金流排名获取数据
        效率更高，适用于全市场扫描
        """
        logger.info(">>> 正在拉取全市场资金流排名...")
        try:
            # 获取全部股票资金流向排名
            df = ak.stock_individual_fund_flow_rank(indicator='今日')
            if df is not None and len(df) > 0:
                # 统一列名
                col_map = {
                    '代码': 'symbol', '名称': 'name',
                    '主力净流入-净额': 'main_net_inflow',
                    '主力净流入-净占比': 'main_net_inflow_pct',
                }
                df = df.rename(columns={k: v for k, v in col_map.items() if k in df.columns})
                if 'symbol' in df.columns:
                    df['symbol'] = df['symbol'].apply(_to_six_digit)
                self.fund_flow = df
                logger.info(f"    全市场资金流拉取 {len(df)} 条记录")
                return df
        except Exception as e:
            logger.warning(f"    资金流排名拉取失败: {e}")

        return pd.DataFrame()

    # ------------------------------------------------------------------
    # 5. 基本面/估值数据拉取
    # ------------------------------------------------------------------

    def fetch_financials(self) -> pd.DataFrame:
        """
        拉取基本面估值数据：PE、PB、ROE、营收增速、净利润增速等
        """
        logger.info(">>> 正在拉取基本面数据...")
        fin_records = []

        if self.stock_list is None or len(self.stock_list) == 0:
            return pd.DataFrame()

        for _, row in self.stock_list.iterrows():
            sym = row['symbol']
            try:
                # 获取个股基本面数据
                info = ak.stock_individual_info_em(symbol=sym)
                if info is not None and len(info) > 0:
                    # info 是两列 DataFrame: item, value
                    record = {'symbol': sym}
                    for _, irow in info.iterrows():
                        item = str(irow.iloc[0])
                        val = irow.iloc[1]
                        if '市盈率' in item:
                            record['pe'] = _safe_float(val)
                        elif '市净率' in item:
                            record['pb'] = _safe_float(val)
                        elif 'ROE' in item or '净资产收益率' in item:
                            record['roe'] = _safe_float(val)
                        elif '营收' in item:
                            record['revenue'] = _safe_float(val)
                        elif '净利润' in item:
                            record['net_profit'] = _safe_float(val)
                    fin_records.append(record)
            except Exception:
                continue
            time.sleep(0.1)

        self.financials = pd.DataFrame(fin_records) if fin_records else pd.DataFrame()
        logger.info(f"    获取到 {len(self.financials)} 只标的基本面数据")
        return self.financials

    # ------------------------------------------------------------------
    # 6. 新闻舆情数据拉取
    # ------------------------------------------------------------------

    def fetch_news_sentiment(self) -> Dict[str, int]:
        """
        拉取当日财经新闻，对每只标的进行简单舆情打分
        正>负 → 正分；负>正 → 负分
        """
        logger.info(">>> 正在拉取财经新闻舆情...")
        sentiment: Dict[str, int] = {}

        # 正面关键词（利好）
        positive_keywords = [
            '业绩预增', '净利润增长', '营收增长', '中标', '签约', '订单',
            '回购', '增持', '分红', '派息', '政策扶持', '补贴', '突破',
            '创新', '专利', '获批', '上市', '新产品', '扩产', '合作',
            '战略合作', '投资', '项目落地', '超预期', '行业龙头',
            '扭亏为盈', '产能释放', '需求旺盛', '量价齐升'
        ]
        # 负面关键词（利空）
        negative_keywords = [
            '业绩预亏', '亏损', '下滑', '减持', '质押', '暴雷', '问询',
            '监管', '处罚', '罚款', '诉讼', '违约', '退市', 'ST',
            '商誉减值', '计提', '停产', '裁员', '债务', '逾期',
            '限售解禁', '大股东减持', '高管减持', '跌停', '利空',
            '大幅下调', '评级下调', '目标价下调'
        ]

        try:
            # 拉取当日财经新闻
            news_df = ak.stock_info_global_em()
            if news_df is not None and len(news_df) > 0:
                title_col = None
                for c in ['标题', 'title', '内容', 'content']:
                    if c in news_df.columns:
                        title_col = c
                        break
                if title_col:
                    for _, nrow in news_df.iterrows():
                        title = str(nrow[title_col])
                        pos_count = sum(1 for kw in positive_keywords if kw in title)
                        neg_count = sum(1 for kw in negative_keywords if kw in title)

                        # 尝试匹配股票代码/名称
                        if self.stock_list is not None:
                            for _, srow in self.stock_list.iterrows():
                                sym = srow['symbol']
                                name = str(srow.get('name', ''))
                                if sym in title or name in title:
                                    if sym not in sentiment:
                                        sentiment[sym] = 0
                                    sentiment[sym] += (pos_count - neg_count)
        except Exception as e:
            logger.warning(f"    新闻舆情拉取异常: {e}")

        logger.info(f"    舆情覆盖 {len(sentiment)} 只标的")
        self.news_sentiment = sentiment
        return sentiment

    # ------------------------------------------------------------------
    # 7. 组装全部数据（一站式调用）
    # ------------------------------------------------------------------

    def run_full_pipeline(self, fast_liquidity: bool = True) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict]:
        """
        一站式全流程数据拉取
        参数:
            fast_liquidity: True=快速流动性筛选, False=精细20日均额筛选（耗时更长）
        返回:
            (stock_list, fund_flow, financials, news_sentiment)
        """
        # Step 1: 拉取股票列表 & 基础过滤
        self.fetch_stock_list()
        if self.stock_list is None or len(self.stock_list) == 0:
            logger.error("    未获取到任何股票数据，退出数据管线")
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), {}

        # Step 2: 流动性筛选
        if fast_liquidity:
            self.filter_liquidity_fast()
        else:
            self.filter_by_liquidity()

        # Step 3: 涨跌幅风险过滤
        self.filter_price_limit_risk()

        # Step 4: 资金流
        self.fetch_fund_flow_ranking()

        # Step 5: 基本面
        self.fetch_financials()

        # Step 6: 新闻舆情
        self.fetch_news_sentiment()

        logger.info(f"=== 数据管线完成：{len(self.stock_list)} 只合规标的 ===")
        return self.stock_list, self.fund_flow, self.financials, self.news_sentiment


# ============================================================================
# 单例快捷函数（便于外部调用）
# ============================================================================

_fetcher_instance: Optional[AStockDataFetcher] = None


def get_fetcher() -> AStockDataFetcher:
    """获取全局单例DataFetcher"""
    global _fetcher_instance
    if _fetcher_instance is None:
        _fetcher_instance = AStockDataFetcher()
    return _fetcher_instance


# ============================================================================
# 自测入口
# ============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("data_fetch.py 自测")
    print("=" * 60)
    fetcher = AStockDataFetcher()
    stocks, funds, fins, news = fetcher.run_full_pipeline(fast_liquidity=True)
    print(f"\n合规标的数: {len(stocks)}")
    if len(stocks) > 0:
        print(f"前5只标的:\n{stocks[['symbol','name','latest_price']].head() if all(c in stocks.columns for c in ['symbol','name','latest_price']) else stocks.head()}")
    print(f"资金流覆盖: {len(funds) if funds is not None else 0} 只")
    print(f"基本面覆盖: {len(fins) if fins is not None else 0} 只")
    print(f"舆情覆盖: {len(news)} 只")
