# 🏆 驼灵「智投未来」A股日内投资AI流水线

驼灵智能体大赛参赛项目 — 基于AKShare数据源的A股日内量化投资决策系统。

## 快速启动

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 配置API密钥
编辑 `.env` 文件，填入DeepSeek API Key（用于AI股票助手）：
```
DEEPSEEK_API_KEY=sk-your-key-here
```

### 3. 启动

**方式A — CLI一键运行：**
```bash
python 5.py
```
输出大赛标准JSON交易指令，直接复制提交。

**方式B — Web仪表板：**
```bash
streamlit run web_ui.py
```
打开浏览器 `http://localhost:8501`，可视化面板 + AI股票助手。

**方式C — Gradio界面：**
```bash
python web_agent.py
```

## 核心功能

| 模块 | 功能 |
|------|------|
| 市场筛选 | 全A股 → 流动性过滤 → 海选池Top20 → 精选池Top6 |
| 五因子打分 | 资金流向(40%) + 趋势形态(20%) + 动量振幅(15%) + 量价匹配(15%) + 北向资金(10%) |
| AI分析师 | 技术面/基本面/资金流/舆情四大维度 + DeepSeek AI深度报告 |
| 多空辩论 | 三轮辩论(陈述→驳斥→修正)，net score判定多空倾向 |
| 仓位分配 | 波动率动态折扣 + 总预算同比例压缩 + 风险标签过滤 |
| 盈亏结算 | 大赛标准公式 + 止损止盈 + 每日强制平仓(无隔夜持仓) |
| 报告输出 | 大赛JSON + Trace审计 + Markdown答辩报告 |
| 复利累积 | 自动继承前日结算资产，连续回测 |

## 文件结构

```
tuoling-agent/
├── 5.py                 # 核心引擎(自包含~7900行)，CLI入口
├── web_ui.py            # Streamlit Web仪表板 + AI股票助手
├── web_agent.py         # Gradio Web界面
├── capital_manager.py   # 资金管理与风控仓位模块
├── strategy_core.py     # 策略核心(五因子/分析师/辩论)
├── data_fetch.py        # AKShare数据获取层
├── agent_output.py      # 输出格式化
├── explain_report.py    # 答辩报告生成
├── requirements.txt     # pip依赖
├── .env                 # API密钥配置
└── README.md
```

## 免责声明

本程序仅供驼灵智能体大赛学术模拟使用，不构成任何真实投资建议。投资有风险，入市需谨慎。
